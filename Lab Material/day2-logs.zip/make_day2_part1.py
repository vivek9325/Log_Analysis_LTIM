#!/usr/bin/env python3
"""Create the Day 2 Part 1 lab pack: one incident in web, application and database logs.

  web/access.log           Nginx combined format + rt= urt= req_id=   (host web-01)
  app/checkout-api.json    JSON Lines from the checkout API and the reprice batch job (host app-01)
  db/postgresql.log        PostgreSQL, log_line_prefix '%m [%p] user=%u db=%d app=%a '  (host db-01)
  splunk/day2_lab/         a Splunk app: indexes web, app, db and the sourcetypes for the files

The hour is 09:00 to 10:00 UTC on 6 November 2026. Everything is invented and
deterministic: the same files every run.
Run:  python3 make_day2_part1.py [target-dir]      (default: ~/day2-logs)
"""
import json
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "day2-logs")
for d in ("web", "app", "db", "splunk/day2_lab/default", "splunk/day2_lab/metadata"):
    (root / d).mkdir(parents=True, exist_ok=True)
rnd = random.Random(20261106 + 21)
UTC = timezone.utc
T0 = datetime(2026, 11, 6, 9, 0, 0, tzinfo=UTC)
END = 3600.0
LOCK_START, LOCK_END = 40 * 60 + 13.402, 47 * 60 + 31.6134     # reprice batch holds the row locks
NPE_START, NPE_END = 12 * 60 + 5.0, 13 * 60 + 50.0             # unrelated bug in the coupon code
PROXY_TIMEOUT, STMT_TIMEOUT = 5.0, 8.0


def T(s):
    return T0 + timedelta(seconds=s)


def ms3(t):
    return f"{t.microsecond // 1000:03d}"


def nginx_time(s):
    return T(s).strftime("%d/%b/%Y:%H:%M:%S +0000")


def iso(s):
    t = T(s)
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + ms3(t) + "Z"


def pg_time(s):
    t = T(s)
    return t.strftime("%Y-%m-%d %H:%M:%S.") + ms3(t) + " UTC"


def hexid(n):
    return "".join(rnd.choice("0123456789abcdef") for _ in range(n))


web, app, db = [], [], []
CLIENTS = [f"198.51.100.{n}" for n in range(2, 120)] + [f"203.0.113.{n}" for n in range(5, 60)]
UAS = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/130.0 Safari/537.36",
       "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148",
       "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6) AppleWebKit/605.1.15 Version/18.1 Safari/605.1.15",
       "Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0"]
SKUS = [f"SKU-{n:05d}" for n in range(10010, 10090, 3)]
TERMS = ["boots", "scarf", "gloves", "jacket", "kettle", "lamp", "backpack", "headphones"]
REF = "https://shop.example.com"


def web_line(end_s, ip, method, uri, status, size, ref, ua, rt, urt, rid):
    urt_s = f"{urt:.3f}" if urt is not None else "-"
    web.append((end_s, f'{ip} - - [{nginx_time(end_s)}] "{method} {uri} HTTP/1.1" {status} {size} "{ref}" "{ua}" '
                       f'rt={rt:.3f} urt={urt_s} req_id={rid}'))


def app_log(s, level, service, msg, **kv):
    d = {"timestamp": iso(s), "level": level, "service": service,
         "hostname": "app-01" if service == "checkout-api" else "batch-01"}
    d.update(kv)
    d["msg"] = msg
    app.append((s, json.dumps(d, separators=(",", ":"))))


def pg(s, pid, user, dbn, appn, level, text):
    db.append((s, f"{pg_time(s)} [{pid}] user={user} db={dbn} app={appn} {level}:  {text}"))


def pg_group(s, pid, user, dbn, appn, items):
    """several lines written by one backend at the same moment, kept in order"""
    for i, (level, text) in enumerate(items):
        db.append((s + i * 1e-7, f"{pg_time(s)} [{pid}] user={user} db={dbn} app={appn} {level}:  {text}"))


order_seq = [771200]
pid_pool = list(range(4401, 4425))
busy = {}
xid_batch = 918273


def api_request(s, ip, ua, method, path, query=""):
    rid = hexid(32)
    uri = path + (f"?{query}" if query else "")
    route = f"{method} {path}"
    if path.startswith("/api/orders/"):
        route = f"{method} /api/orders/{{id}}"
    # ---- the checkout during the lock: blocked in the database
    if method == "POST" and path == "/api/checkout" and LOCK_START <= s < LOCK_END:
        free = [p for p in pid_pool if busy.get(p, -1) < s]
        pid = rnd.choice(free)
        sku = rnd.choice(SKUS)
        a0 = s + 0.002
        app_log(a0, "INFO", "checkout-api", "checkout started", request_id=rid, method=method, path=path,
                items=rnd.randint(1, 4))
        q0 = a0 + rnd.randint(8, 30) / 1000
        stmt = (f"UPDATE inventory SET reserved = reserved + $1 WHERE sku = $2 /*request_id='{rid}'*/")
        w = q0 + 1.0 + rnd.random() / 2000
        if w < LOCK_END:
            pg_group(w, pid, "checkout", "shop", "checkout-api", [
                ("LOG", f"process {pid} still waiting for ShareLock on transaction {xid_batch} after "
                        f"{(w - q0) * 1000:.3f} ms"),
                ("DETAIL", f"Process holding the lock: 3301. Wait queue: {pid}."),
                ("CONTEXT", f'while updating tuple ({rnd.randint(3, 40)},{rnd.randint(1, 30)}) in relation "inventory"'),
                ("STATEMENT", stmt)])
        if q0 + STMT_TIMEOUT <= LOCK_END:
            e = q0 + STMT_TIMEOUT + rnd.randint(0, 4) / 1000
            busy[pid] = e
            pg_group(e, pid, "checkout", "shop", "checkout-api", [
                ("ERROR", "canceling statement due to statement timeout"),
                ("STATEMENT", stmt)])
            a1 = e + 0.004
            app_log(a1, "ERROR", "checkout-api", "Statement timeout reserving stock", request_id=rid, method=method,
                    path=path, sku=sku, duration_ms=round((a1 - a0) * 1000),
                    error_type="org.postgresql.util.PSQLException",
                    error_message="ERROR: canceling statement due to statement timeout")
            app_log(a1 + 0.002, "WARN", "checkout-api", "Response not sent: client disconnected", request_id=rid,
                    method=method, path=path, status=500, duration_ms=round((a1 + 0.002 - a0) * 1000))
        else:
            # the batch committed while this statement was still waiting: it goes through, late
            done = LOCK_END + rnd.randint(2, 9) / 1000
            busy[pid] = done
            if done - q0 >= 0.25:
                pg(done, pid, "checkout", "shop", "checkout-api", "LOG",
                   f"duration: {(done - q0) * 1000:.3f} ms  execute <unnamed>: {stmt}")
            order_seq[0] += 1
            a1 = done + rnd.randint(60, 120) / 1000
            app_log(a1, "INFO", "checkout-api", "order placed", request_id=rid, method=method, path=path,
                    status=201, duration_ms=round((a1 - a0) * 1000), order_id=f"ORD-{order_seq[0]}")
            if a1 + 0.002 - s > PROXY_TIMEOUT:
                app_log(a1 + 0.002, "WARN", "checkout-api", "Response not sent: client disconnected",
                        request_id=rid, method=method, path=path, status=201,
                        duration_ms=round((a1 + 0.002 - a0) * 1000), order_id=f"ORD-{order_seq[0]}")
            else:
                end = a1 + 0.003
                web_line(end, ip, method, uri, 201, rnd.randint(80, 400), f"{REF}/cart", ua, end - s, end - s - 0.001, rid)
                return
        end = s + PROXY_TIMEOUT + rnd.randint(1, 3) / 1000
        web_line(end, ip, method, uri, 504, 160, f"{REF}/cart", ua, end - s, end - s - 0.001, rid)
        return
    # ---- the unrelated bug: coupon codes on add-to-cart
    if method == "POST" and path == "/api/cart/items" and NPE_START <= s < NPE_END and rnd.random() < 0.55:
        a0 = s + 0.002
        a1 = a0 + rnd.randint(9, 25) / 1000
        app_log(a1, "ERROR", "checkout-api", "Unhandled exception applying coupon", request_id=rid, method=method,
                path=path, status=500, duration_ms=round((a1 - a0) * 1000),
                error_type="java.lang.NullPointerException",
                error_message='Cannot invoke "Coupon.getRate()" because "coupon" is null')
        end = a1 + 0.003
        web_line(end, ip, method, uri, 500, 182, f"{REF}/cart", ua, end - s, end - s - 0.001, rid)
        return
    # ---- normal API traffic
    a0 = s + 0.002
    if path == "/api/checkout":
        dur = rnd.randint(90, 260) / 1000
        status = 201
        order_seq[0] += rnd.randint(1, 3)
        app_log(a0, "INFO", "checkout-api", "checkout started", request_id=rid, method=method, path=path,
                items=rnd.randint(1, 4))
        app_log(a0 + dur - 0.003, "INFO", "checkout-api", "order placed", request_id=rid, method=method, path=path,
                status=status, duration_ms=round(dur * 1000), order_id=f"ORD-{order_seq[0]}")
    else:
        dur = rnd.randint(6, 45) / 1000
        status = 404 if (path.startswith("/api/orders/") and rnd.random() < 0.08) else (201 if method == "POST" else 200)
        app_log(a0 + dur - 0.001, "WARN" if status == 404 else "INFO", "checkout-api",
                "order not found" if status == 404 else "request completed", request_id=rid, method=method,
                path=path, status=status, duration_ms=round(dur * 1000))
    end = a0 + dur + 0.002
    size = {200: rnd.randint(300, 3000), 201: rnd.randint(80, 400), 404: 98}[status]
    web_line(end, ip, method, uri, status, size, f"{REF}/", ua, end - s, end - s - 0.001, rid)


def page_request(s, ip, ua):
    r = rnd.random()
    if r < 0.30:
        uri, status, size, dur = f"/static/{rnd.choice(['app.js', 'app.css', 'logo.svg', 'fonts/inter.woff2'])}", 200, rnd.randint(2000, 90000), rnd.randint(1, 6) / 1000
    elif r < 0.62:
        uri, status, size, dur = f"/products/{rnd.choice(SKUS).lower()}", 200, rnd.randint(8000, 22000), rnd.randint(20, 90) / 1000
    elif r < 0.80:
        q = rnd.choice(TERMS)
        slow = rnd.random() < 0.04
        dur = rnd.randint(320, 900) / 1000 if slow else rnd.randint(40, 160) / 1000
        uri, status, size = f"/search?q={q}", 200, rnd.randint(5000, 15000)
        if slow:
            pg(s + dur - 0.01, rnd.choice(range(4430, 4440)), "catalog", "shop", "storefront", "LOG",
               f"duration: {dur * 1000 - 12 + rnd.random():.3f} ms  execute <unnamed>: SELECT id, name, price FROM products "
               f"WHERE name ILIKE $1 ORDER BY popularity DESC LIMIT 48")
    elif r < 0.97:
        uri, status, size, dur = "/", 200, rnd.randint(14000, 16000), rnd.randint(15, 60) / 1000
    else:
        uri, status, size, dur = rnd.choice(["/wp-login.php", "/.env", "/old-sale", "/favicon.ico"]), 404, 153, 0.001
    end = s + dur
    rid = hexid(32)
    web_line(end, ip, "GET", uri, status, size, f"{REF}/" if uri != "/" else "-", ua, dur,
             None if uri.startswith("/static") or status == 404 else max(dur - 0.001, 0.0), rid)


s = 0.0
while s < END:
    s += rnd.expovariate(2.4)
    if s >= END - 10:
        break
    ip, ua = rnd.choice(CLIENTS), rnd.choice(UAS)
    r = rnd.random()
    if r < 0.62:
        page_request(s, ip, ua)
    elif r < 0.76:
        api_request(s, ip, ua, "GET", "/api/cart")
    elif r < 0.86:
        api_request(s, ip, ua, "POST", "/api/cart/items")
    elif r < 0.935:
        api_request(s, ip, ua, "POST", "/api/checkout")
    else:
        api_request(s, ip, ua, "GET", f"/api/orders/ORD-{rnd.randint(770000, 771200)}")

# load balancer health checks every 10 s
for k in range(0, 360):
    hs = k * 10 + 0.5
    web_line(hs + 0.001, "192.0.2.10", "GET", "/health", 200, 2, "-", "ELB-HealthChecker/2.0", 0.001, 0.001, hexid(32))

# the reprice batch job: one long transaction that locks every winter SKU row
app_log(LOCK_START - 0.051, "INFO", "reprice-batch", "Repricing started", job_id="reprice-20261106-0940",
        category="winter", skus=18412)
app_log(LOCK_END + 0.020, "INFO", "reprice-batch", "Repricing finished", job_id="reprice-20261106-0940",
        category="winter", skus=18412, duration_ms=round((LOCK_END + 0.020 - LOCK_START + 0.051) * 1000))
pg(LOCK_END, 3301, "batch", "shop", "reprice-batch", "LOG",
   f"duration: {(LOCK_END - LOCK_START) * 1000:.3f} ms  statement: UPDATE inventory SET price = round(price * 1.05, 2), "
   f"updated_at = now() WHERE category_id IN (SELECT id FROM categories WHERE season = 'winter')")
# background database noise
for k in range(1, 12):
    cs = k * 300 + 0.25
    pg(cs, 61, "", "", "", "LOG", "checkpoint starting: time")
    pg(cs + 28.6 + rnd.random(), 61, "", "", "", "LOG",
       f"checkpoint complete: wrote {rnd.randint(300, 2400)} buffers ({rnd.uniform(1, 9):.1f}%); "
       f"write={rnd.uniform(25, 29):.3f} s, sync={rnd.uniform(0.01, 0.2):.3f} s, total={rnd.uniform(28, 29.9):.3f} s")
for k in range(3):
    av = rnd.uniform(200, 3300)
    pg(av, rnd.randint(5100, 5199), "", "", "", "LOG",
       f'automatic vacuum of table "shop.public.cart_items": index scans: 1, pages: 0 removed, {rnd.randint(800, 3000)} remain')

# ------------------------------------------------------------------ write
(root / "web/access.log").write_text("\n".join(l for _, l in sorted(web, key=lambda x: x[0])) + "\n")
(root / "app/checkout-api.json").write_text("\n".join(l for _, l in sorted(app, key=lambda x: x[0])) + "\n")
(root / "db/postgresql.log").write_text("\n".join(l for _, l in sorted(db, key=lambda x: x[0])) + "\n")

APP = root / "splunk/day2_lab"
(APP / "default/app.conf").write_text(
    "[install]\nstate = enabled\n\n[ui]\nis_visible = false\nlabel = Day 2 log analysis lab\n\n"
    "[launcher]\nversion = 1.0.0\ndescription = Indexes and sourcetypes for the Day 2 lab files\n")
idx = ""
for name in ("web", "app", "db"):
    idx += (f"[{name}]\nhomePath = $SPLUNK_DB/{name}/db\ncoldPath = $SPLUNK_DB/{name}/colddb\n"
            f"thawedPath = $SPLUNK_DB/{name}/thaweddb\nfrozenTimePeriodInSecs = 188697600\n\n")
(APP / "default/indexes.conf").write_text(idx)
(APP / "default/props.conf").write_text(r"""[checkout:json]
SHOULD_LINEMERGE = false
LINE_BREAKER = ([\r\n]+)
KV_MODE = json
TIME_PREFIX = "timestamp":"
TIME_FORMAT = %Y-%m-%dT%H:%M:%S.%3NZ
TZ = UTC
MAX_TIMESTAMP_LOOKAHEAD = 30

[postgresql]
SHOULD_LINEMERGE = false
LINE_BREAKER = ([\r\n]+)
TIME_PREFIX = ^
TIME_FORMAT = %Y-%m-%d %H:%M:%S.%3N UTC
TZ = UTC
MAX_TIMESTAMP_LOOKAHEAD = 30
KV_MODE = none
EXTRACT-prefix = ^\S+ \S+ UTC \[(?<pid>\d+)\] user=(?<pg_user>\S*) db=(?<pg_db>\S*) app=(?<app>\S*) (?<pg_level>[A-Z]+):
EXTRACT-duration = duration: (?<duration_ms>[\d.]+) ms
EXTRACT-request_id = request_id='(?<request_id>[0-9a-f]+)'
EXTRACT-holder = Process holding the lock: (?<holder_pid>\d+)
""")
(APP / "metadata/default.meta").write_text("[]\naccess = read : [ * ], write : [ admin ]\nexport = system\n")

print(f"wrote {root}")
print(f"  web/access.log         {len(web):>6} lines")
print(f"  app/checkout-api.json  {len(app):>6} lines")
print(f"  db/postgresql.log      {len(db):>6} lines")
print("  splunk/day2_lab/       Splunk app: indexes web, app, db; sourcetypes checkout:json, postgresql")
