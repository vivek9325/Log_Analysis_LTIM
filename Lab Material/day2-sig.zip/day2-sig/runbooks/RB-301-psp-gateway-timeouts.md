# RB-301: Payment provider timeouts

**Service:** payments-worker  
**Owner:** Team Payments

## Impact

Charges are retried; customers may wait or see a pending payment.

## Checks

1. Check the provider's status page and our egress proxy.
2. Compare the timeout rate with the retry rate (`Retry n/5` lines).

## Mitigation

1. If the provider is degraded, enable the queue-and-retry mode: `featureflag set payments.async_capture on`.

## Escalation

Payments lead if more than 5% of charges time out for 15 minutes.
