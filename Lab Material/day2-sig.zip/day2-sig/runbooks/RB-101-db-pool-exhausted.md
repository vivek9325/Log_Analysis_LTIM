# RB-101: Database connection pool exhausted

**Service:** orders-api  
**Owner:** Team Orders (on-call: orders-oncall)

## Impact

Checkout and order history fail or time out; Nginx returns 503 or 504 for /api/checkout.

## Checks

1. Check pool metrics: `hikaricp_connections_active`, `hikaricp_connections_pending` for pool HikariPool-1.
2. In PostgreSQL, look for long transactions and lock waits: `SELECT pid, now() - xact_start AS age, state, left(query, 60) FROM pg_stat_activity WHERE datname = 'orders' ORDER BY age DESC LIMIT 10;`
3. Check whether a deploy or batch job started in the last 30 minutes.

## Mitigation

1. If a single session holds locks for minutes, cancel it: `SELECT pg_cancel_backend(<pid>);` (terminate only with DBA approval).
2. If traffic is simply higher, scale orders-api out; do not raise `maximumPoolSize` above the database's connection budget.
3. If a deploy started the problem, roll it back.

## Escalation

DBA on-call if locks persist after 10 minutes.
