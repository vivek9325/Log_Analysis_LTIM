# RB-201: Cart cache (Redis) unavailable

**Service:** orders-api  
**Owner:** Platform team

## Impact

Carts load from the database instead of the cache: slower, more database load.

## Checks

1. `redis-cli -h cache-01.internal ping`
2. Check the cache node's memory and `maxclients`, and recent failovers.

## Mitigation

1. Restart or fail over the cache node.
2. Watch RB-101 signals: the fallback adds database load.

## Escalation

Platform on-call if the cache is down for more than 15 minutes.
