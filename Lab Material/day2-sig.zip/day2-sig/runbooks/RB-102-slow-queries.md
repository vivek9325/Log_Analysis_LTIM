# RB-102: Slow queries

**Service:** orders-api  
**Owner:** Team Orders

## Impact

Pages load slowly; can lead to pool exhaustion (RB-101) if it persists.

## Checks

1. Find the statement and its plan: `EXPLAIN (ANALYZE, BUFFERS)` with the values from an example line.
2. Check for missing indexes on `orders(customer_id, created_at)`.

## Mitigation

1. Add or fix the index in a reviewed migration.
2. If one customer causes it (a bot), rate-limit that client.

## Escalation

None outside working hours unless RB-101 also fires.
