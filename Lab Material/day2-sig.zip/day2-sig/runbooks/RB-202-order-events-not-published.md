# RB-202: Order events not published to Kafka

**Service:** orders-api  
**Owner:** Team Orders

## Impact

Downstream services (shipping, e-mail) miss orders; orders themselves succeed.

## Checks

1. `kafka-topics.sh --describe --topic orders.v1` on a broker
2. Check broker health and the producer's `bootstrap.servers`.

## Mitigation

1. Fix the topic or broker, then replay missed events from the outbox table: `bin/replay-outbox --since <time>`.

## Escalation

Data platform on-call.
