# RB-900: Expected condition: no action

**Service:** any  
**Owner:** Owning team

## Impact

None: the event records a normal business or client outcome (declined card, expired token, retry that succeeded, oversized upload).

## Checks

1. Nothing per event. Watch the rate: a sudden change can still mean a problem (for example, all cards declined).

## Mitigation

1. None. If the rate changes sharply, open the runbook of the dependency involved.

## Escalation

None.
