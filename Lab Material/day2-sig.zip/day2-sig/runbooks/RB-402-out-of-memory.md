# RB-402: Out of memory

**Service:** orders-api  
**Owner:** Team Orders

## Impact

The JVM may stop responding or be restarted by the orchestrator.

## Checks

1. Check restarts: `kubectl get pods -l app=orders-api`.
2. Find the operation in the stack trace (here: report export).

## Mitigation

1. Restart the pod if it is unhealthy.
2. Limit the size of the operation (paginate the export) in a code fix.

## Escalation

Team Orders.
