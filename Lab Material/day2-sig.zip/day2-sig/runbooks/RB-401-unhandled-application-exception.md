# RB-401: Unhandled application exception (code bug)

**Service:** any  
**Owner:** Owning team of the top frame

## Impact

Requests that hit the bug fail with HTTP 500.

## Checks

1. Read the exception message and the top application frame in the signature.
2. Check when the signature first appeared and whether a deploy happened just before.
3. Count affected requests per minute.

## Mitigation

1. If a deploy introduced it and more than 1% of requests fail, roll back.
2. Otherwise open a bug for the owning team, with the signature ID, an example and the count.

## Escalation

Owning team's on-call if the error rate is above 1% of requests.
