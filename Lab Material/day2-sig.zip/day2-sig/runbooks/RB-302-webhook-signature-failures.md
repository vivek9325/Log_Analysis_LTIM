# RB-302: Webhook signature verification failures

**Service:** payments-worker  
**Owner:** Team Payments + Security

## Impact

Payment status updates are rejected; could be a rotated secret or forged requests.

## Checks

1. Check whether the webhook secret was rotated recently.
2. Check the source addresses of the failing requests in the access log.

## Mitigation

1. Update the secret from the vault if it was rotated.
2. If the sources are unknown, block them and inform Security.

## Escalation

Security on-call for any sign of forged requests.
