# RB-xxx: <one problem, in a few words>

**Service:** <service>  
**Owner:** <team>  
**Signatures:** <SIG-... IDs, or the rule in rules.csv that maps here>

## Impact

<What users or other services notice.>

## Checks

1. <A command or query that confirms the cause.>
2. <One that rules out the most likely other cause.>

## Mitigation

1. <The safest action first, with its limits.>
2. <The next one.>

## Escalation

<When, and to whom.>
