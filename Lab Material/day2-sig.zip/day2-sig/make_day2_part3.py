#!/usr/bin/env python3
"""Build the Day 2 Part 3 lab files (error signatures, runbooks, log-to-metric).

Writes ~/day2-sig/logs/{baseline,today}/ with:
  orders-api.log         Java (logback) application log with multi-line stack traces
  payments-worker.jsonl  Python service, one JSON object per line, tracebacks inside
  access.log             Nginx combined log with rt= and req_id=
baseline = 12 November 2026, a normal day. today = 13 November 2026: release
2026.11.13-2 of orders-api went out at 15:00 UTC and checkout errors followed.

Every value is invented: addresses come from the documentation ranges, host names
use example.com and .internal, and the random generator is seeded, so the output is
the same on every run.
"""
import json
import os
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(os.path.expanduser("~/day2-sig"))
UTC = timezone.utc
CLIENTS = ["192.0.2.10", "192.0.2.44", "198.51.100.7", "198.51.100.23", "198.51.100.45",
           "198.51.100.102", "203.0.113.9", "203.0.113.77", "203.0.113.128", "203.0.113.254"]
UA = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X)",
      "Mozilla/5.0 (X11; Linux x86_64)", "okhttp/4.12.0"]


def hexid(r, n):
    return "".join(r.choice("0123456789abcdef") for _ in range(n))


def uuid4(r):
    h = hexid(r, 32)
    return f"{h[:8]}-{h[8:12]}-4{h[13:16]}-{r.choice('89ab')}{h[17:20]}-{h[20:32]}"


def day_times(r, day, n, start_h=0, end_h=24, weight_day=True):
    """n timestamps on `day`, more during working hours when weight_day is set."""
    out = []
    while len(out) < n:
        sec = r.uniform(start_h * 3600, end_h * 3600)
        h = sec / 3600
        if weight_day and r.random() > (0.25 + 0.75 * (7 <= h <= 21)):
            continue
        out.append(day + timedelta(seconds=sec))
    return sorted(out)


def burst(r, start, minutes, n):
    return sorted(start + timedelta(seconds=r.uniform(0, minutes * 60)) for _ in range(n))


# ----------------------------------------------------------------- orders-api
THREADS = [f"http-nio-8080-exec-{i}" for i in range(1, 21)]
JAVA_FRAMES = {
    "tax88": ["\tat com.example.orders.tax.TaxService.calculate(TaxService.java:{line})",
              "\tat com.example.orders.checkout.CheckoutService.price(CheckoutService.java:142)",
              "\tat com.example.orders.api.CheckoutController.checkout(CheckoutController.java:61)",
              "\tat java.base/jdk.internal.reflect.DirectMethodHandleAccessor.invoke(DirectMethodHandleAccessor.java:103)",
              "\tat org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:885)"],
    "promo": ["\tat com.example.orders.promo.PromoService.apply(PromoService.java:57)",
              "\tat com.example.orders.checkout.CheckoutService.price(CheckoutService.java:139)",
              "\tat com.example.orders.api.CheckoutController.checkout(CheckoutController.java:61)",
              "\tat org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:885)"],
    "redis": ["\tat io.lettuce.core.RedisConnectionException.create(RedisConnectionException.java:78)",
              "\tat io.lettuce.core.AbstractRedisClient.getConnection(AbstractRedisClient.java:350)",
              "\tat com.example.orders.cache.CartCache.get(CartCache.java:44)",
              "\tat com.example.orders.api.CartController.view(CartController.java:37)"],
    "oom": ["\tat java.base/java.util.Arrays.copyOf(Arrays.java:3537)",
            "\tat com.example.orders.report.ExportService.toCsv(ExportService.java:112)",
            "\tat com.example.orders.api.ReportController.export(ReportController.java:29)"],
}


def jline(t, level, thread, logger, msg):
    return f"{t.strftime('%Y-%m-%d %H:%M:%S')}.{t.microsecond // 1000:03d} {level:<5} [{thread}] {logger} - {msg}"


def orders_events(r, day, today):
    ev = []  # (time, [lines])
    th = lambda: r.choice(THREADS)
    # normal traffic
    for t in day_times(r, day, 2600):
        k = r.random()
        if k < 0.55:
            oid = r.randint(80000, 99999)
            ev.append((t, [jline(t, "INFO", th(), "c.e.orders.api.CheckoutController",
                                 f"Order {oid} created for customer C-{r.randint(1000, 9999)} total={r.randint(5, 400)}.{r.randint(0, 99):02d} EUR items={r.randint(1, 6)}")]))
        elif k < 0.85:
            ev.append((t, [jline(t, "INFO", th(), "c.e.orders.api.CartController",
                                 f"Cart {uuid4(r)} updated: {r.randint(1, 8)} items")]))
        else:
            ev.append((t, [jline(t, "DEBUG", th(), "c.e.orders.inventory.StockClient",
                                 f"GET http://inventory.internal:8080/stock/SKU-{r.randint(10000, 99999)} 200 in {r.randint(4, 90)} ms")]))

    def add(times, fn):
        for t in times:
            ev.append((t, fn(t)))

    pool = lambda t: [jline(t, "ERROR", th(), "c.e.orders.db.OrderRepository",
                            f"Timeout acquiring connection from pool HikariPool-{r.choice([1, 1, 1, 2])} after 30000ms "
                            f"(active=20, idle=0, waiting={r.randint(3, 60)})")]
    add(day_times(r, day, 38), pool)
    if today:
        add(burst(r, day + timedelta(hours=15, minutes=2), 22, 140), pool)
    reasons = ["card_expired"] * 5 + ["insufficient_funds"] * 4 + ["do_not_honor"] * 2
    add(day_times(r, day, 120), lambda t: [jline(t, "WARN", th(), "c.e.orders.payments.PaymentClient",
                                                 f"Payment declined for order {r.randint(80000, 99999)}: {r.choice(reasons)}")])
    add(day_times(r, day, 85), lambda t: [jline(t, "WARN", th(), "c.e.orders.inventory.StockClient",
                                                f"Retrying GET http://inventory.internal:8080/stock/SKU-{r.randint(10000, 99999)} "
                                                f"(attempt {r.randint(2, 3)} of 3)")])
    npe_line = 88 if not today else None

    def npe(t):
        line = npe_line or (88 if t.hour < 15 else 91)       # the release moved the line
        return ([jline(t, "ERROR", th(), "c.e.orders.api.CheckoutController",
                       f"Unhandled exception for request {hexid(r, 32)}"),
                 'java.lang.NullPointerException: Cannot invoke "com.example.orders.model.Address.getCountry()" because "shipping" is null']
                + [f.format(line=line) for f in JAVA_FRAMES["tax88"]])
    add(day_times(r, day, 14), npe)

    def redis(t):
        return ([jline(t, "ERROR", th(), "c.e.orders.cache.CartCache", "Cart cache unavailable, falling back to database"),
                 f"io.lettuce.core.RedisConnectionException: Unable to connect to cache-01.internal/10.20.4.17:6379"]
                + JAVA_FRAMES["redis"]
                + ["Caused by: io.netty.channel.ConnectTimeoutException: connection timed out after 2000 ms: cache-01.internal/10.20.4.17:6379",
                   "\t... 4 common frames omitted"])
    add(day_times(r, day, 9), redis)
    add(day_times(r, day, 6), lambda t: [jline(t, "ERROR", th(), "c.e.orders.messaging.EventPublisher",
                                               f"Failed to publish OrderCreated event {uuid4(r)} to topic orders.v1: "
                                               "org.apache.kafka.common.errors.TimeoutException: Topic orders.v1 not present in metadata after 60000 ms.")])

    def jwt(t):
        exp = t - timedelta(seconds=r.randint(30, 900))
        return [jline(t, "WARN", th(), "c.e.orders.security.JwtFilter",
                      f"JWT expired at {exp.strftime('%Y-%m-%dT%H:%M:%SZ')}. Current time: {t.strftime('%Y-%m-%dT%H:%M:%SZ')}, "
                      f"a difference of {int((t - exp).total_seconds() * 1000)} milliseconds.")]
    add(day_times(r, day, 52), jwt)
    add(day_times(r, day, 11), lambda t: [jline(t, "ERROR", th(), "c.e.orders.api.GlobalExceptionHandler",
                                                f"413 Request entity too large: {r.choice([2097152, 5242880, 8388608])} bytes > limit 1048576 bytes")])
    add(day_times(r, day, 40), lambda t: [jline(t, "WARN", th(), "c.e.orders.db.QueryLogger",
                                                f"Slow query ({r.randint(1001, 4800)} ms): SELECT * FROM orders WHERE customer_id = "
                                                f"'C-{r.randint(1000, 9999)}' AND created_at > '2026-1{r.randint(0, 1)}-{r.randint(10, 28)}'")])
    if not today:
        t = day + timedelta(hours=3, minutes=12, seconds=7.25)
        ev.append((t, [jline(t, "ERROR", "report-export-1", "c.e.orders.report.ExportService", "Export of report 4471 failed"),
                       "java.lang.OutOfMemoryError: Java heap space"] + JAVA_FRAMES["oom"]))
    if today:
        dep = day + timedelta(hours=15)
        ev.append((dep, [jline(dep, "INFO", "main", "c.e.orders.Application",
                               "Started OrdersApplication in 8.412 seconds (release 2026.11.13-2)")]))
        add(burst(r, dep + timedelta(minutes=1), 90, 64), lambda t: [jline(t, "ERROR", th(), "c.e.orders.tax.TaxClient",
                                                                           f"Tax provider returned HTTP 429: rate limit exceeded (retry_after={r.choice([10, 30, 60])}s)")])

        def npe2(t):
            return ([jline(t, "ERROR", th(), "c.e.orders.api.CheckoutController", f"Unhandled exception for request {hexid(r, 32)}"),
                     'java.lang.NullPointerException: Cannot invoke "java.util.List.size()" because "promo.codes" is null']
                    + JAVA_FRAMES["promo"])
        add(burst(r, dep + timedelta(minutes=3), 300, 23), npe2)
    return ev


# ------------------------------------------------------------ payments-worker
def pj(t, level, logger, msg, **kw):
    d = {"ts": t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond // 1000:03d}Z", "level": level,
         "service": "payments-worker", "logger": logger, "msg": msg}
    d.update(kw)
    return json.dumps(d)


def payments_events(r, day, today):
    ev = []
    for t in day_times(r, day, 900):
        ev.append((t, [pj(t, "INFO", "worker.charges", f"Charge ch_{hexid(r, 16)} captured: {r.randint(5, 400)}.{r.randint(0, 99):02d} EUR")]))

    def add(times, fn):
        for t in times:
            ev.append((t, [fn(t)]))
    tb_timeout = ('Traceback (most recent call last):\n  File "/app/worker/psp.py", line 64, in post_charge\n'
                  '    resp = self.session.post(url, json=body, timeout=10)\n'
                  'requests.exceptions.ReadTimeout: HTTPSConnectionPool(host=\'psp.example.com\', port=443): Read timed out. (read timeout=10)')
    add(day_times(r, day, 22), lambda t: pj(t, "ERROR", "worker.psp", "Gateway timeout calling https://psp.example.com/v1/charges after 10.0s",
                                            error={"type": "requests.exceptions.ReadTimeout", "stack": tb_timeout}))
    add(day_times(r, day, 15), lambda t: pj(t, "WARN", "worker.charges", f"Idempotency key {uuid4(r)} already used, returning stored result"))
    tb_sig = ('Traceback (most recent call last):\n  File "/app/worker/webhooks.py", line 31, in verify\n'
              '    hmac_check(payload, header, secret)\nworker.errors.SignatureError: signature mismatch')
    add(day_times(r, day, 7), lambda t: pj(t, "ERROR", "worker.webhooks", f"Webhook signature verification failed for event evt_{hexid(r, 24)}",
                                           error={"type": "worker.errors.SignatureError", "stack": tb_sig}))
    add(day_times(r, day, 30), lambda t: pj(t, "WARN", "worker.charges", f"Retry {r.randint(1, 4)}/5 for charge ch_{hexid(r, 16)}"))
    if today:
        tb_key = ('Traceback (most recent call last):\n  File "/app/worker/charges.py", line 118, in build_payload\n'
                  '    "reference": order["merchant_ref"],\nKeyError: \'merchant_ref\'')
        add(burst(r, day + timedelta(hours=15, minutes=4), 240, 11),
            lambda t: pj(t, "ERROR", "worker.charges", f"Cannot build charge for order {r.randint(80000, 99999)}",
                         error={"type": "KeyError", "stack": tb_key}))
    return ev


# ---------------------------------------------------------------- access log
ROUTES = [("GET", "/", 0.10), ("GET", "/api/products/{id}", 0.30), ("GET", "/api/cart", 0.15),
          ("POST", "/api/cart", 0.10), ("POST", "/api/checkout", 0.08), ("GET", "/api/orders/{id}", 0.07),
          ("GET", "/static/app.js", 0.12), ("GET", "/health", 0.08)]


def access_lines(r, day, today, n):
    out = []
    w = [x[2] for x in ROUTES]
    inc0, inc1 = day + timedelta(hours=15, minutes=2), day + timedelta(hours=15, minutes=24)
    for t in day_times(r, day, n):
        m, path, _ = r.choices(ROUTES, w)[0]
        path = path.replace("{id}", str(r.randint(10000, 99999)))
        status, rt = (200 if m == "GET" else 201), r.uniform(0.004, 0.4)
        x = r.random()
        if path == "/static/app.js" and x < 0.3:
            status = 304
        elif x < 0.012:
            status = r.choice([400, 401, 404, 404, 404])
        elif x < 0.0145:
            status = r.choice([500, 502, 503, 504])
        if today and inc0 <= t < inc1 and path in ("/api/checkout", "/api/cart") and r.random() < (0.8 if path == "/api/checkout" else 0.25):
            status = r.choice([503, 503, 504, 500])
            rt = 30.0 if status == 504 else r.uniform(0.01, 2.5)
        if today and t >= day + timedelta(hours=15) and path == "/api/checkout" and status < 400 and r.random() < 0.04:
            status = 500
        size = 0 if status == 304 else r.randint(150, 9000)
        out.append(f'{r.choice(CLIENTS)} - - [{t.strftime("%d/%b/%Y:%H:%M:%S")} +0000] "{m} {path} HTTP/1.1" {status} {size} '
                   f'"https://shop.example.com/" "{r.choice(UA)}" rt={rt:.3f} req_id={hexid(r, 32)}')
    return out


def write(path, events):
    path.parent.mkdir(parents=True, exist_ok=True)
    events.sort(key=lambda e: e[0])
    path.write_text("".join(l + "\n" for _, ls in events for l in ls))


def main():
    for name, day, today, seed in [("baseline", datetime(2026, 11, 12, tzinfo=UTC), False, 1112),
                                   ("today", datetime(2026, 11, 13, tzinfo=UTC), True, 1113)]:
        r = random.Random(seed)
        d = ROOT / "logs" / name
        write(d / "orders-api.log", orders_events(r, day, today))
        write(d / "payments-worker.jsonl", payments_events(r, day, today))
        (d / "access.log").write_text("\n".join(access_lines(r, day, today, 30000)) + "\n")
    print("wrote", ROOT / "logs")


if __name__ == "__main__":
    main()
