# Find-AppFailures.ps1 - application failures from the event logs and from log files, in one report
param(
    [int]$Hours = 1,
    [string]$LogFolder = 'C:\LabLogs',
    [string]$Pattern = '\[(ERR|FTL)\]',
    [string]$Csv = "$env:TEMP\app-failures.csv"
)
$since = (Get-Date).AddHours(-$Hours)
$known = 1000, 1001, 1002, 1026, 7000, 7009, 7031, 7034, 5002, 5011

# 1. Critical and Error events from Application and System
$events = Get-WinEvent -ErrorAction SilentlyContinue -FilterHashtable @{
    LogName = 'Application', 'System'; Level = 1, 2; StartTime = $since }
$rows = foreach ($e in $events) {
    [pscustomobject]@{
        Time    = $e.TimeCreated
        Source  = "$($e.LogName)/$($e.ProviderName)"
        Id      = $e.Id
        Known   = $known -contains $e.Id
        Summary = ($e.Message -split "`r?`n")[0]
    }
}

# 2. Error lines in the application's own log files
$lines = Get-ChildItem $LogFolder -Filter *.log -ErrorAction SilentlyContinue |
    Select-String -Pattern $Pattern |
    ForEach-Object { [pscustomobject]@{ File = $_.Filename; Line = $_.LineNumber; Text = $_.Line.Trim() } }

# 3. Report
$rows | Sort-Object Time | Format-Table Time, Source, Id, Known, Summary -AutoSize
$lines | Group-Object File | Select-Object Count, Name | Format-Table -AutoSize
$rows | Export-Csv $Csv -NoTypeInformation
"{0} event(s) and {1} log line(s) since {2:HH:mm}. Events saved to {3}" -f @($rows).Count, @($lines).Count, $since, $Csv
