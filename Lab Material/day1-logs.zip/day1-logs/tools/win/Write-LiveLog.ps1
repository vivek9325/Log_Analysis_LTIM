# Write-LiveLog.ps1 - append a line to a log every half second, like a running service
param([string]$Path = '.\live.log', [int]$Seconds = 120)
$end = (Get-Date).AddSeconds($Seconds); $n = 0
while ((Get-Date) -lt $end) {
    $n++
    $lvl = if ($n % 9 -eq 0) { 'ERR' } elseif ($n % 5 -eq 0) { 'WRN' } else { 'INF' }
    $msg = switch ($lvl) {
        'ERR'   { "Checkout failed for cart $(70000 + $n): payments returned 502" }
        'WRN'   { "Slow search query took $(1500 + 37 * $n) ms" }
        default { "Checkout completed for cart $(70000 + $n)" }
    }
    $ts = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss.fff')
    Add-Content -Path $Path -Value "$ts +00:00 [$lvl] Shop.Api.Checkout: $msg"
    Start-Sleep -Milliseconds 500
}
