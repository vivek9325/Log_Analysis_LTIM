Day 1 Part 4 sample logs: one shop, seven components, 10:14 to 10:16:30 UTC on 6 Nov 2026.
All data is invented. See the Part 4 lab guide (Labs 1.14 to 1.16).
Helpers: ../bin/trace.py ID FILE...   and   ../bin/spantree.py [--list | --trace ID | --cid ID] spans.json
