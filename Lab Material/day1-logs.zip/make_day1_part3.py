#!/usr/bin/env python3
"""Add the Day 1 Part 3 sample logs to the lab pack (~/day1-logs/tools).

Creates: tools/access.log (Nginx, one hour), tools/payments.logfmt (key=value),
tools/orders.json (JSON Lines), tools/win/shop-api.log and tools/win/u_ex261106.log
(Windows-style application and IIS logs) and bin/livelog.py (a live log writer).
Everything is invented and deterministic: the same files every run.
Run:  python3 make_day1_part3.py [target-dir]      (default: ~/day1-logs)
"""
import json
import os
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "day1-logs")
tools = root / "tools"
(tools / "win").mkdir(parents=True, exist_ok=True)
(tools / "live").mkdir(parents=True, exist_ok=True)
(root / "bin").mkdir(parents=True, exist_ok=True)
rnd = random.Random(20261106)
UTC = timezone.utc
T0 = datetime(2026, 11, 6, 14, 0, 0, tzinfo=UTC)


def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond // 1000:03d}Z"


# ------------------------------------------------------------------ tools/access.log
CLIENTS = [f"198.51.100.{n}" for n in range(10, 70)]
UAS = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X)",
       "Mozilla/5.0 (X11; Linux x86_64)", "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6)"]
TERMS = ["shoes", "laptop", "kettle", "headphones", "desk+lamp", "yoga+mat", "backpack"]
rows = []
t = T0
while t < T0 + timedelta(hours=1):
    t += timedelta(milliseconds=rnd.randint(250, 950))
    ip = rnd.choice(CLIENTS)
    ua = rnd.choice(UAS)
    r = rnd.random()
    incident = T0 + timedelta(minutes=20) <= t < T0 + timedelta(minutes=26, seconds=30)
    if r < 0.22:
        req, st, by, rt = "GET / HTTP/1.1", 200, 5120, rnd.uniform(0.002, 0.02)
    elif r < 0.40:
        req, st, by, rt = f"GET /static/{rnd.choice(['app.js', 'app.css', 'logo.svg'])} HTTP/1.1", rnd.choice([200, 304, 304]), 0, rnd.uniform(0.001, 0.004)
        by = 0 if st == 304 else rnd.choice([48210, 9120, 3311])
    elif r < 0.58:
        req, st, by, rt = f"GET /product/{rnd.randint(1000, 1299)} HTTP/1.1", 200, rnd.randint(6000, 9000), rnd.uniform(0.02, 0.09)
    elif r < 0.72:
        q = rnd.choice(TERMS)
        req, st, by, rt = f"GET /search?q={q} HTTP/1.1", 200, rnd.randint(12000, 30000), rnd.uniform(0.4, 1.3) + (rnd.uniform(1.0, 2.6) if q == "laptop" else 0)
    elif r < 0.84:
        req, st, by, rt = "GET /cart HTTP/1.1", 200, rnd.randint(400, 900), rnd.uniform(0.02, 0.06)
    elif r < 0.94:
        if incident and rnd.random() < 0.72:
            st = rnd.choice([502, 502, 502, 504])
            req, by, rt = "POST /api/checkout HTTP/1.1", 166, (rnd.uniform(3.0, 3.1) if st == 502 else 10.0)
        else:
            req, st, by, rt = "POST /api/checkout HTTP/1.1", 201, 88, rnd.uniform(0.18, 0.42)
    else:
        req, st, by, rt = "GET /account/orders HTTP/1.1", 200, rnd.randint(2000, 4000), rnd.uniform(0.04, 0.12)
    ref = "-" if req.startswith("GET / ") else "https://shop.example.com/"
    rows.append((t, f'{ip} - - [{t.strftime("%d/%b/%Y:%H:%M:%S")} +0000] "{req}" {st} {by} "{ref}" "{ua}" {rt:.3f}'))
# a scanner, 14:41-14:43
SCAN = ["/wp-login.php", "/.env", "/admin", "/phpmyadmin/", "/.git/config", "/backup.zip", "/xmlrpc.php", "/config.php", "/server-status", "/api/v1/users"]
t = T0 + timedelta(minutes=41, seconds=3)
for k in range(180):
    t += timedelta(milliseconds=rnd.randint(300, 900))
    rows.append((t, f'203.0.113.77 - - [{t.strftime("%d/%b/%Y:%H:%M:%S")} +0000] "GET {SCAN[k % len(SCAN)]} HTTP/1.1" {403 if SCAN[k % len(SCAN)] == "/server-status" else 404} 153 "-" "python-requests/2.32.3" 0.001'))
rows.sort(key=lambda r: r[0])
(tools / "access.log").write_text("\n".join(r[1] for r in rows) + "\n")

# ------------------------------------------------------------------ tools/payments.logfmt
P = []
t = T0
order = 31800
while t < T0 + timedelta(hours=1):
    t += timedelta(milliseconds=rnd.randint(2500, 6000))
    order += 1
    incident = T0 + timedelta(minutes=20) <= t < T0 + timedelta(minutes=26, seconds=30)
    gw = rnd.choice(["acme-pay", "acme-pay", "acme-pay", "orbit-pay"])
    amt = f"{rnd.uniform(5, 250):.2f}"
    if incident and gw == "acme-pay" and rnd.random() < 0.8:
        for a in (1, 2, 3):
            P.append((t, f'ts={iso(t)} level=warn svc=payments msg="gateway timeout, retrying" order={order} gateway={gw} attempt={a} duration_ms=1000'))
            t += timedelta(milliseconds=1001)
        P.append((t, f'ts={iso(t)} level=error svc=payments msg="payment failed" order={order} gateway={gw} amount_eur={amt} reason=gateway_timeout duration_ms=3002'))
    else:
        d = rnd.randint(120, 380) if gw == "acme-pay" else rnd.randint(200, 520)
        if rnd.random() < 0.06:
            P.append((t, f'ts={iso(t)} level=info svc=payments msg="payment declined" order={order} gateway={gw} amount_eur={amt} reason=insufficient_funds duration_ms={d}'))
        else:
            P.append((t, f'ts={iso(t)} level=info svc=payments msg="payment authorised" order={order} gateway={gw} amount_eur={amt} duration_ms={d}'))
    if rnd.random() < 0.08:
        P.append((t + timedelta(milliseconds=3), f'ts={iso(t + timedelta(milliseconds=3))} level=debug svc=payments msg="fx rate cached" pair=EUR/INR ttl_s=300'))
(tools / "payments.logfmt").write_text("\n".join(r[1] for r in sorted(P)) + "\n")

# ------------------------------------------------------------------ tools/orders.json
O = []
t = T0
for k in range(420):
    t += timedelta(milliseconds=rnd.randint(5000, 11000))
    if t >= T0 + timedelta(hours=1):
        break
    items = [{"sku": f"SKU-{rnd.randint(1000, 1299)}", "qty": rnd.randint(1, 3)} for _ in range(rnd.randint(1, 4))]
    tier = rnd.choice(["standard", "standard", "standard", "gold", "platinum"])
    incident = T0 + timedelta(minutes=20) <= t < T0 + timedelta(minutes=26, seconds=30)
    status = "failed" if incident and rnd.random() < 0.6 else "created"
    O.append(json.dumps({"ts": iso(t), "level": "error" if status == "failed" else "info", "event": f"order_{status}",
                         "order_id": 52000 + k, "customer": {"id": f"c-{rnd.randint(10000, 99999)}", "tier": tier, "country": rnd.choice(["IN", "IN", "IN", "DE", "US", "GB"])},
                         "items": items, "total_eur": round(sum(i["qty"] for i in items) * rnd.uniform(8, 60), 2),
                         "duration_ms": rnd.randint(3000, 3300) if status == "failed" else rnd.randint(150, 600)}, separators=(",", ":")))
(tools / "orders.json").write_text("\n".join(O) + "\n")

# ------------------------------------------------------------------ tools/win/shop-api.log  (Serilog text, as a Windows service writes it)
W = []
t = T0


def ser(t, lvl, ctx, msg):
    return f"{t.strftime('%Y-%m-%d %H:%M:%S.')}{t.microsecond // 1000:03d} +00:00 [{lvl}] {ctx}: {msg}"


W.append(ser(t, "INF", "Microsoft.Hosting.Lifetime", "Application started. Hosting environment: Production"))
while t < T0 + timedelta(hours=1):
    t += timedelta(milliseconds=rnd.randint(4000, 9000))
    incident = T0 + timedelta(minutes=20) <= t < T0 + timedelta(minutes=26, seconds=30)
    if incident and rnd.random() < 0.7:
        W.append(ser(t, "ERR", "Shop.Api.Checkout.CheckoutController", f"Checkout failed for cart {rnd.randint(70000, 79999)}"))
        W.append("System.Net.Http.HttpRequestException: Response status code does not indicate success: 502 (Bad Gateway).")
        W.append("   at System.Net.Http.HttpResponseMessage.EnsureSuccessStatusCode()")
        W.append("   at Shop.Api.Payments.PaymentsClient.AuthoriseAsync(PaymentRequest request) in C:\\src\\Shop.Api\\Payments\\PaymentsClient.cs:line 48")
        W.append("   at Shop.Api.Checkout.CheckoutController.Post(CheckoutRequest body) in C:\\src\\Shop.Api\\Checkout\\CheckoutController.cs:line 37")
    elif rnd.random() < 0.06:
        W.append(ser(t, "WRN", "Shop.Api.Search.SearchService", f"Slow search query 'laptop' took {rnd.randint(1800, 3800)} ms"))
    else:
        W.append(ser(t, "INF", "Shop.Api.Checkout.CheckoutController", f"Checkout completed for cart {rnd.randint(70000, 79999)} in {rnd.randint(180, 420)} ms"))
(tools / "win" / "shop-api.log").write_text("\r\n".join(W) + "\r\n")

# ------------------------------------------------------------------ tools/win/u_ex261106.log (IIS W3C for the same hour)
I = ["#Software: Microsoft Internet Information Services 10.0", "#Version: 1.0", "#Date: 2026-11-06 14:00:00",
     "#Fields: date time s-ip cs-method cs-uri-stem cs-uri-query s-port cs-username c-ip cs(User-Agent) cs(Referer) sc-status sc-substatus sc-win32-status time-taken"]
for tt, line in rows[::4]:
    p = line.split('"')
    meth, path, _ = p[1].split(" ")
    stem, _, q = path.partition("?")
    st = int(p[2].split()[0])
    tt_ms = int(float(line.rsplit(" ", 1)[1]) * 1000)
    ip = line.split(" ")[0]
    ua = p[5].replace(" ", "+")
    sub, win = (3, 12002) if st == 502 else (0, 1460) if st == 504 else (0, 2) if st == 404 else (0, 0)
    I.append(f"{tt.strftime('%Y-%m-%d %H:%M:%S')} 10.0.1.15 {meth} {stem} {q or '-'} 443 - {ip} {ua} - {st} {sub} {win} {tt_ms}")
(tools / "win" / "u_ex261106.log").write_text("\r\n".join(I) + "\r\n")

# ------------------------------------------------------------------ bin/livelog.py
LIVE = r'''#!/usr/bin/env python3
"""Write a live application log, one line every --interval seconds, for --seconds.
With --rotate-after N, rename the file to <file>.1 after N lines and start a new
file, as logrotate's "create" mode does.

usage: livelog.py [--file tools/live/app.log] [--seconds 60] [--interval 0.5] [--rotate-after N]
"""
import argparse, os, random, time
from datetime import datetime, timezone

ap = argparse.ArgumentParser()
ap.add_argument("--file", default="tools/live/app.log")
ap.add_argument("--seconds", type=float, default=60)
ap.add_argument("--interval", type=float, default=0.5)
ap.add_argument("--rotate-after", type=int, default=0)
ap.add_argument("--seed", type=int, default=7)
a = ap.parse_args()
rnd = random.Random(a.seed)
os.makedirs(os.path.dirname(a.file) or ".", exist_ok=True)
f = open(a.file, "a", buffering=1)
end, n = time.time() + a.seconds, 0
while time.time() < end:
    n += 1
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    r = rnd.random()
    if r < 0.08:
        line = f"{now} ERROR [worker-{n % 4 + 1}] c.shop.payments.Gateway - payment failed order={40000 + n} reason=gateway_timeout"
    elif r < 0.18:
        line = f"{now} WARN  [worker-{n % 4 + 1}] c.shop.payments.Gateway - slow gateway response latency_ms={rnd.randint(1200, 2900)}"
    else:
        line = f"{now} INFO  [worker-{n % 4 + 1}] c.shop.payments.Gateway - payment authorised order={40000 + n} latency_ms={rnd.randint(90, 400)}"
    f.write(line + "\n")
    if a.rotate_after and n == a.rotate_after:
        f.close()
        os.replace(a.file, a.file + ".1")
        f = open(a.file, "a", buffering=1)
        print(f"livelog: rotated {a.file} -> {a.file}.1 after {n} lines", flush=True)
    time.sleep(a.interval)
f.close()
'''
(root / "bin" / "livelog.py").write_text(LIVE)
os.chmod(root / "bin" / "livelog.py", 0o755)

print(f"Part 3 sample logs written to {tools}")
for p in sorted(tools.rglob("*")):
    if p.is_file():
        print(f"  {p.relative_to(root)}  ({sum(1 for _ in open(p, encoding='utf-8'))} lines)")
