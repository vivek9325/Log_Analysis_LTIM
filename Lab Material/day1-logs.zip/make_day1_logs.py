#!/usr/bin/env python3
"""Create the Day 1 lab pack: ~/day1-logs with sample logs in several formats.

Every host, user, IP address and order number is invented. IP addresses come
from the documentation ranges (RFC 5737), so nothing points at a real system.
Run:  python3 make_day1_logs.py [target-dir]      (default: ~/day1-logs)
"""
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "day1-logs")
for sub in ("app", "system", "web", "formats", "windows", "rotate"):
    (root / sub).mkdir(parents=True, exist_ok=True)

UTC = timezone.utc
IST = timezone(timedelta(hours=5, minutes=30))
T0 = datetime(2026, 11, 6, 9, 12, 1, 4000, tzinfo=UTC)


def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond // 1000:03d}Z"


def at(sec, ms=0):
    return T0 + timedelta(seconds=sec, milliseconds=ms)


# ---------------------------------------------------------------- app/payment-service.log
# Log4j / Logback pattern: %d{ISO8601,UTC}Z %-5level [%thread] %logger{36} - %msg%n
P = []  # (time, level, thread, logger, message, [continuation lines])
P.append((at(0), "INFO", "main", "o.s.b.StartupInfoLogger", "Starting PaymentService v2.4.1 on pay-01 with PID 4412", []))
P.append((at(3, 513), "INFO", "main", "c.z.hikari.HikariDataSource", "HikariPool-1 - Start completed.", []))
P.append((at(5, 898), "INFO", "main", "o.s.b.w.e.tomcat.TomcatWebServer", "Tomcat started on port 8080 (http)", []))
P.append((at(5, 914), "INFO", "main", "o.s.b.StartupInfoLogger", "Started PaymentService in 6.1 seconds", []))
P.append((at(30), "DEBUG", "HikariPool-1 housekeeper", "c.z.hikari.pool.HikariPool", "HikariPool-1 - Pool stats (total=10, active=0, idle=10, waiting=0)", []))

orders = [(10471, 49.90, 1, 212), (10472, 18.00, 2, 188), (10473, 120.50, 3, 240), (10474, 9.99, 4, 175),
          (10475, 64.00, 5, 301), (10476, 33.25, 6, 198), (10477, 210.00, 8, 266), (10478, 15.75, 1, 183),
          (10479, 88.40, 2, 2480), (10480, 42.00, 3, 207), (10481, 12.60, 4, 192)]
sec = 41
for n, (oid, amt, th, ms) in enumerate(orders):
    thr = f"http-nio-8080-exec-{th}"
    P.append((at(sec, 100 + n), "INFO", thr, "c.shop.payment.PaymentService", f"Authorising card payment order={oid} amount={amt:.2f} currency=EUR", []))
    if ms > 2000:
        P.append((at(sec, 100 + n + ms - 20), "WARN", thr, "c.shop.payment.GatewayClient", f"Gateway slow response order={oid} latency_ms={ms} threshold_ms=2000", []))
    P.append((at(sec, 100 + n + ms), "INFO", thr, "c.shop.payment.PaymentService", f"Payment authorised order={oid} auth_ms={ms}", []))
    sec += 9

# the incident: order 10482 on exec-7, three attempts then failure (ends 09:14:27.512Z)
inc = datetime(2026, 11, 6, 9, 14, 18, 497000, tzinfo=UTC)
P.append((inc, "INFO", "http-nio-8080-exec-7", "c.shop.payment.PaymentService", "Authorising card payment order=10482 amount=76.30 currency=EUR", []))
for k in range(1, 4):
    t = inc + timedelta(milliseconds=3000 * k + 2 * k)
    lvl = "WARN" if k < 3 else "ERROR"
    P.append((t, lvl, "http-nio-8080-exec-7", "c.shop.payment.GatewayClient", f"Gateway call failed order=10482 attempt={k}/3 error=SocketTimeoutException", []))
P.append((datetime(2026, 11, 6, 9, 14, 27, 512000, tzinfo=UTC), "ERROR", "http-nio-8080-exec-7", "c.shop.payment.PaymentService",
          "Card authorisation failed for order 10482: gateway timeout after 3000 ms",
          ["c.shop.payment.GatewayTimeoutException: no response from gw.pay.example.com:443 within 3000 ms",
           "\tat c.shop.payment.GatewayClient.authorise(GatewayClient.java:118)",
           "\tat c.shop.payment.PaymentService.authorise(PaymentService.java:72)",
           "\tat c.shop.payment.PaymentController.pay(PaymentController.java:41)",
           "Caused by: java.net.SocketTimeoutException: Read timed out",
           "\tat java.base/sun.nio.ch.NioSocketImpl.timedRead(NioSocketImpl.java:288)",
           "\t... 48 more"]))
P.append((datetime(2026, 11, 6, 9, 14, 21, 640000, tzinfo=UTC), "INFO", "http-nio-8080-exec-2", "c.shop.payment.PaymentService", "Authorising card payment order=10483 amount=27.80 currency=EUR", []))
P.append((datetime(2026, 11, 6, 9, 14, 21, 871000, tzinfo=UTC), "INFO", "http-nio-8080-exec-2", "c.shop.payment.PaymentService", "Payment authorised order=10483 auth_ms=231", []))
P.append((datetime(2026, 11, 6, 9, 14, 30, 4000, tzinfo=UTC), "DEBUG", "HikariPool-1 housekeeper", "c.z.hikari.pool.HikariPool", "HikariPool-1 - Pool stats (total=10, active=4, idle=6, waiting=0)", []))
P.append((datetime(2026, 11, 6, 9, 14, 33, 220000, tzinfo=UTC), "WARN", "http-nio-8080-exec-5", "c.shop.payment.PaymentService", "Card declined order=10484 reason=insufficient_funds", []))
P.append((datetime(2026, 11, 6, 9, 15, 0, 3000, tzinfo=UTC), "ERROR", "scheduling-1", "c.shop.payment.RefundJob", "Refund batch failed: connection refused to refunds-db:5432 (batch=118, pending=6)", []))
P.append((datetime(2026, 11, 6, 9, 15, 0, 9000, tzinfo=UTC), "INFO", "scheduling-1", "c.shop.payment.RefundJob", "Refund batch 118 will retry at 09:20:00Z", []))
P.sort(key=lambda r: r[0])
with open(root / "app" / "payment-service.log", "w") as f:
    for t, lvl, thr, lg, msg, extra in P:
        f.write(f"{iso(t)} {lvl:<5} [{thr}] {lg} - {msg}\n")
        for e in extra:
            f.write(e + "\n")

# ---------------------------------------------------------------- app/orders-api.log
# Python logging, local time (IST, no offset written!): %(asctime)s %(levelname)s [%(threadName)s] %(name)s: %(message)s
O = [
    ("2026-11-06 14:42:00,118", "INFO", "MainThread", "orders.app", "Starting orders-api 1.9.0 (workers=4)"),
    ("2026-11-06 14:42:00,402", "INFO", "MainThread", "orders.db", "Connected to orders-db:5432/orders"),
    ("2026-11-06 14:43:53,987", "INFO", "worker-1", "orders.api", "POST /api/orders order=10479 items=3"),
    ("2026-11-06 14:43:56,601", "WARNING", "worker-1", "orders.payment", "Payment call slow order=10479 elapsed_ms=2614"),
    ("2026-11-06 14:43:56,609", "INFO", "worker-1", "orders.api", "201 Created order=10479"),
    ("2026-11-06 14:44:18,455", "INFO", "worker-3", "orders.api", "POST /api/orders order=10482 items=2"),
    ("2026-11-06 14:44:21,602", "INFO", "worker-2", "orders.api", "POST /api/orders order=10483 items=1"),
    ("2026-11-06 14:44:21,905", "INFO", "worker-2", "orders.api", "201 Created order=10483"),
    ("2026-11-06 14:44:27,530", "ERROR", "worker-3", "orders.payment", "Payment service returned 502 for order 10482 (upstream timeout)"),
    ("2026-11-06 14:44:27,533", "INFO", "worker-3", "orders.api", "502 Bad Gateway order=10482"),
    ("2026-11-06 14:44:33,190", "INFO", "worker-4", "orders.api", "POST /api/orders order=10484 items=5"),
    ("2026-11-06 14:44:33,251", "WARNING", "worker-4", "orders.payment", "Payment declined order=10484"),
    ("2026-11-06 14:44:33,256", "INFO", "worker-4", "orders.api", "402 Payment Required order=10484"),
    ("2026-11-06 14:45:00,010", "DEBUG", "scheduler", "orders.metrics", "queue_depth=0 open_connections=4"),
]
with open(root / "app" / "orders-api.log", "w") as f:
    for ts, lvl, thr, lg, msg in O:
        f.write(f"{ts} {lvl} [{thr}] {lg}: {msg}\n")

# ---------------------------------------------------------------- system/auth.log (syslog, RFC 3164 style)
A = [
    ("Nov  6 09:10:01", "CRON[2088]", "pam_unix(cron:session): session opened for user root(uid=0) by root(uid=0)"),
    ("Nov  6 09:10:01", "CRON[2088]", "pam_unix(cron:session): session closed for user root"),
    ("Nov  6 09:11:42", "sshd[2133]", "Accepted publickey for trainee from 192.0.2.10 port 50122 ssh2: ED25519 SHA256:k3Yx0aQ1vZf9Lr2mWq8sT4uE6bN0cD5hJ7pR1oI2sAg"),
    ("Nov  6 09:11:42", "sshd[2133]", "pam_unix(sshd:session): session opened for user trainee(uid=1001) by trainee(uid=0)"),
    ("Nov  6 09:11:42", "systemd-logind[812]", "New session 7 of user trainee."),
    ("Nov  6 09:13:05", "sshd[2141]", "Invalid user admin from 203.0.113.45 port 52110"),
    ("Nov  6 09:13:07", "sshd[2141]", "Failed password for invalid user admin from 203.0.113.45 port 52110 ssh2"),
    ("Nov  6 09:13:11", "sshd[2141]", "Failed password for invalid user admin from 203.0.113.45 port 52110 ssh2"),
    ("Nov  6 09:13:15", "sshd[2141]", "Connection closed by invalid user admin 203.0.113.45 port 52110 [preauth]"),
    ("Nov  6 09:13:20", "sshd[2150]", "Invalid user oracle from 203.0.113.45 port 52114"),
    ("Nov  6 09:13:22", "sshd[2150]", "Failed password for invalid user oracle from 203.0.113.45 port 52114 ssh2"),
    ("Nov  6 09:13:30", "sshd[2155]", "Failed password for root from 203.0.113.45 port 52118 ssh2"),
    ("Nov  6 09:13:34", "sshd[2155]", "Failed password for root from 203.0.113.45 port 52118 ssh2"),
    ("Nov  6 09:13:38", "sshd[2155]", "error: maximum authentication attempts exceeded for root from 203.0.113.45 port 52118 ssh2 [preauth]"),
    ("Nov  6 09:15:10", "sudo", "  trainee : TTY=pts/0 ; PWD=/home/trainee ; USER=root ; COMMAND=/usr/bin/tail -n 50 /var/log/syslog"),
    ("Nov  6 09:15:10", "sudo", "pam_unix(sudo:session): session opened for user root(uid=0) by trainee(uid=1001)"),
    ("Nov  6 09:15:10", "sudo", "pam_unix(sudo:session): session closed for user root"),
    ("Nov  6 09:17:01", "CRON[2241]", "pam_unix(cron:session): session opened for user root(uid=0) by root(uid=0)"),
    ("Nov  6 09:17:01", "CRON[2241]", "pam_unix(cron:session): session closed for user root"),
    ("Nov  6 09:19:55", "sshd[2133]", "Received disconnect from 192.0.2.10 port 50122:11: disconnected by user"),
]
with open(root / "system" / "auth.log", "w") as f:
    for ts, prog, msg in A:
        f.write(f"{ts} web01 {prog}: {msg}\n")

# ---------------------------------------------------------------- web/access.log (nginx combined + $request_time)
W = [
    ("198.51.100.23", "09:13:58", "GET / HTTP/1.1", 200, 5120, "-", 0.004),
    ("198.51.100.23", "09:13:58", "GET /static/app.js HTTP/1.1", 200, 48210, "https://shop.example.com/", 0.002),
    ("198.51.100.23", "09:13:59", "GET /static/app.css HTTP/1.1", 200, 9120, "https://shop.example.com/", 0.001),
    ("198.51.100.77", "09:14:02", "GET / HTTP/1.1", 200, 5120, "-", 0.005),
    ("198.51.100.77", "09:14:03", "GET /static/app.js HTTP/1.1", 304, 0, "https://shop.example.com/", 0.001),
    ("198.51.100.77", "09:14:06", "GET /product/1188 HTTP/1.1", 200, 7421, "https://shop.example.com/", 0.031),
    ("198.51.100.23", "09:14:09", "GET /cart HTTP/1.1", 200, 512, "https://shop.example.com/", 0.046),
    ("192.0.2.200", "09:14:11", "GET /wp-login.php HTTP/1.1", 404, 153, "-", 0.001),
    ("192.0.2.200", "09:14:11", "GET /.env HTTP/1.1", 404, 153, "-", 0.001),
    ("198.51.100.77", "09:14:14", "GET /cart HTTP/1.1", 200, 498, "https://shop.example.com/product/1188", 0.039),
    ("198.51.100.91", "09:14:21", "POST /api/orders HTTP/1.1", 201, 88, "https://shop.example.com/cart", 0.312),
    ("198.51.100.23", "09:14:27", "POST /api/orders HTTP/1.1", 502, 166, "https://shop.example.com/cart", 9.081),
    ("198.51.100.23", "09:14:29", "GET /cart HTTP/1.1", 200, 512, "https://shop.example.com/cart", 0.041),
    ("198.51.100.40", "09:14:33", "POST /api/orders HTTP/1.1", 402, 61, "https://shop.example.com/cart", 0.071),
    ("198.51.100.77", "09:14:40", "GET /checkout HTTP/1.1", 200, 2210, "https://shop.example.com/cart", 0.052),
    ("198.51.100.23", "09:14:44", "POST /api/orders HTTP/1.1", 201, 88, "https://shop.example.com/cart", 0.288),
    ("192.0.2.200", "09:14:47", "GET /admin HTTP/1.1", 404, 153, "-", 0.001),
    ("198.51.100.91", "09:14:52", "GET /account/orders HTTP/1.1", 200, 3304, "https://shop.example.com/", 0.064),
]
UA = {"198.51.100.23": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "198.51.100.77": "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X)",
      "198.51.100.91": "Mozilla/5.0 (X11; Linux x86_64)", "198.51.100.40": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_6)",
      "192.0.2.200": "python-requests/2.32.3"}
with open(root / "web" / "access.log", "w") as f:
    for ip, hms, req, st, by, ref, rt in W:
        f.write(f'{ip} - - [06/Nov/2026:{hms} +0000] "{req}" {st} {by} "{ref}" "{UA[ip]}" {rt:.3f}\n')

# ---------------------------------------------------------------- windows/u_ex261106.log (IIS W3C extended, UTC)
FIELDS = "date time s-ip cs-method cs-uri-stem cs-uri-query s-port cs-username c-ip cs(User-Agent) cs(Referer) sc-status sc-substatus sc-win32-status time-taken"
I = [
    ("09:14:02", "GET", "/", "-", 443, "198.51.100.77", 200, 0, 0, 15),
    ("09:14:06", "GET", "/product/details.aspx", "id=1188", 443, "198.51.100.77", 200, 0, 0, 62),
    ("09:14:09", "GET", "/cart", "-", 443, "198.51.100.23", 200, 0, 0, 46),
    ("09:14:11", "GET", "/wp-login.php", "-", 443, "192.0.2.200", 404, 0, 2, 3),
    ("09:14:21", "POST", "/api/orders", "-", 443, "198.51.100.91", 201, 0, 0, 312),
    ("09:14:27", "POST", "/api/orders", "-", 443, "198.51.100.23", 502, 3, 12002, 9081),
    ("09:14:33", "POST", "/api/orders", "-", 443, "198.51.100.40", 402, 0, 0, 71),
    ("09:14:40", "GET", "/checkout", "-", 443, "198.51.100.77", 200, 0, 0, 52),
    ("09:14:47", "GET", "/admin", "-", 443, "192.0.2.200", 401, 2, 5, 4),
    ("09:14:52", "GET", "/account/orders", "-", 443, "198.51.100.91", 200, 0, 0, 64),
]
with open(root / "windows" / "u_ex261106.log", "w", newline="\r\n") as f:
    f.write("#Software: Microsoft Internet Information Services 10.0\n#Version: 1.0\n#Date: 2026-11-06 09:14:02\n")
    f.write(f"#Fields: {FIELDS}\n")
    for hms, m, stem, q, port, ip, st, sub, win, tt in I:
        ua = UA[ip].replace(" ", "+")
        f.write(f"2026-11-06 {hms} 10.0.1.15 {m} {stem} {q} {port} - {ip} {ua} - {st} {sub} {win} {tt}\n")

# ---------------------------------------------------------------- formats/sample-a ... sample-f (no extensions on purpose)
F = root / "formats"
with open(F / "sample-a", "w", newline="\r\n") as f:  # W3C extended (IIS FTP-like)
    f.write("#Software: Microsoft Internet Information Services 10.0\n#Version: 1.0\n#Date: 2026-11-06 08:00:00\n")
    f.write("#Fields: date time c-ip cs-username s-ip s-port cs-method cs-uri-stem sc-status sc-win32-status x-session\n")
    for hms, ip, user, m, stem, st, win in [("08:02:11", "192.0.2.31", "ftp-reports", "USER", "ftp-reports", 331, 0),
                                            ("08:02:11", "192.0.2.31", "ftp-reports", "PASS", "***", 230, 0),
                                            ("08:02:14", "192.0.2.31", "ftp-reports", "RETR", "daily-2026-11-05.csv", 226, 0),
                                            ("08:05:40", "203.0.113.9", "anonymous", "USER", "anonymous", 331, 0),
                                            ("08:05:41", "203.0.113.9", "anonymous", "PASS", "***", 530, 1326)]:
        f.write(f"2026-11-06 {hms} {ip} {user} 10.0.1.20 21 {m} {stem} {st} {win} 3f9c1d2e-7a41\n")

recs_b = [
    {"@timestamp": "2026-11-06T09:14:18.455Z", "level": "info", "service": "orders-api", "host": "orders-01", "trace_id": "4bf92f3577b34da6", "message": "order received", "order_id": 10482, "items": 2},
    {"@timestamp": "2026-11-06T09:14:27.530Z", "level": "error", "service": "orders-api", "host": "orders-01", "trace_id": "4bf92f3577b34da6", "message": "payment service returned 502", "order_id": 10482, "upstream": "payment-service", "elapsed_ms": 9075},
    {"@timestamp": "2026-11-06T09:14:27.533Z", "level": "info", "service": "orders-api", "host": "orders-01", "trace_id": "4bf92f3577b34da6", "message": "request completed", "order_id": 10482, "status": 502, "duration_ms": 9078},
    {"@timestamp": "2026-11-06T09:14:33.256Z", "level": "warn", "service": "orders-api", "host": "orders-02", "trace_id": "a3ce929d0e0e4736", "message": "payment declined", "order_id": 10484, "status": 402, "duration_ms": 66},
]
with open(F / "sample-b", "w") as f:  # JSON Lines
    for r in recs_b:
        f.write(json.dumps(r, separators=(",", ":")) + "\n")

with open(F / "sample-c", "w") as f:  # plain text (Log4j)
    for t, lvl, thr, lg, msg, extra in P[-8:-2]:
        f.write(f"{iso(t)} {lvl:<5} [{thr}] {lg} - {msg}\n")
        for e in extra[:2]:
            f.write(e + "\n")

recs_d = [
    {"version": "1.1", "host": "pay-01", "short_message": "Gateway call failed order=10482 attempt=3/3", "timestamp": 1793956467.503, "level": 3, "_service": "payment-service", "_thread": "http-nio-8080-exec-7", "_order_id": 10482, "_logger": "c.shop.payment.GatewayClient"},
    {"version": "1.1", "host": "pay-01", "short_message": "Card authorisation failed for order 10482", "full_message": "c.shop.payment.GatewayTimeoutException: no response from gw.pay.example.com:443 within 3000 ms\n\tat c.shop.payment.GatewayClient.authorise(GatewayClient.java:118)", "timestamp": 1793956467.512, "level": 3, "_service": "payment-service", "_thread": "http-nio-8080-exec-7", "_order_id": 10482, "_logger": "c.shop.payment.PaymentService"},
    {"version": "1.1", "host": "pay-01", "short_message": "Card declined order=10484", "timestamp": 1793956473.22, "level": 4, "_service": "payment-service", "_thread": "http-nio-8080-exec-5", "_order_id": 10484, "_logger": "c.shop.payment.PaymentService"},
    {"version": "1.1", "host": "pay-01", "short_message": "Refund batch failed: connection refused", "timestamp": 1793956500.003, "level": 3, "_service": "payment-service", "_thread": "scheduling-1", "_batch": 118, "_logger": "c.shop.payment.RefundJob"},
]
with open(F / "sample-d", "w") as f:  # GELF
    for r in recs_d:
        f.write(json.dumps(r, separators=(",", ":")) + "\n")

with open(F / "sample-e", "w") as f:  # syslog RFC 5424 (stretch)
    f.write('<86>1 2026-11-06T09:13:07.114Z web01 sshd 2141 - - Failed password for invalid user admin from 203.0.113.45 port 52110 ssh2\n')
    f.write('<38>1 2026-11-06T09:15:10.002Z web01 sudo - - [origin software="sudo"] trainee : TTY=pts/0 ; USER=root ; COMMAND=/usr/bin/tail -n 50 /var/log/syslog\n')
    f.write('<30>1 2026-11-06T09:17:01.000Z web01 systemd 1 - - Started logrotate.service - Rotate log files.\n')

with open(F / "sample-f", "w") as f:  # CRI container log: timestamp stream tag then the app's own line (stretch)
    for r in recs_b[:3]:
        t = r["@timestamp"].replace("Z", "") + "412Z"
        f.write(f"{t} stdout F " + json.dumps(r, separators=(",", ":")) + "\n")

# ---------------------------------------------------------------- rotate/ (used in Lab 1.4)
with open(root / "rotate" / "app.log", "w") as f:
    for i in range(2000):
        t = T0 + timedelta(seconds=i * 3)
        f.write(f"{iso(t)} INFO  [worker-{i % 4 + 1}] c.lab.Heartbeat - heartbeat seq={i} queue_depth={i % 7}\n")

os.chmod(root / "rotate", 0o750)
print(f"Lab pack written to {root}")
for p in sorted(root.rglob("*")):
    if p.is_file():
        print(f"  {p.relative_to(root)}")
