#!/usr/bin/env python3
"""Add the Day 1 Part 2 sample logs to the lab pack (~/day1-logs).

Folders created: levels/, cascade/, java/, dotnet/.
Every host, user, IP address and order number is invented.
Run:  python3 make_day1_part2.py [target-dir]      (default: ~/day1-logs)
"""
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "day1-logs")
for sub in ("levels", "cascade", "java", "dotnet"):
    (root / sub).mkdir(parents=True, exist_ok=True)
UTC = timezone.utc


def iso(t):
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond // 1000:03d}Z"


def T(h, m, s, ms=0):
    return datetime(2026, 11, 6, h, m, s, ms * 1000, tzinfo=UTC)


def l4j(t, lvl, thr, lg, msg):
    return f"{iso(t)} {lvl:<5} [{thr}] {lg} - {msg}"


# ======================================================================== levels/
L = []
t = T(8, 0, 0)
L.append(l4j(t, "INFO", "main", "c.shop.checkout.CheckoutApp", "Starting checkout-service v3.2.0 on chk-01 (PID 3120)"))
L.append(l4j(t + timedelta(seconds=4, milliseconds=210), "INFO", "main", "c.shop.checkout.CheckoutApp", "Started checkout-service in 4.2 seconds"))
for i in range(36):
    tt = t + timedelta(seconds=30 + i * 25, milliseconds=(i * 137) % 1000)
    thr = f"http-nio-8085-exec-{i % 6 + 1}"
    cart = 5100 + i
    if i % 9 == 4:
        L.append(l4j(tt, "ERROR", thr, "c.shop.checkout.PaymentStep", f"Card declined for cart={cart} reason=insufficient_funds"))
    elif i % 7 == 3:
        L.append(l4j(tt, "WARN", thr, "c.shop.checkout.PromoService", "Promo code lookup slow latency_ms=812 threshold_ms=500"))
    elif i == 19:
        L.append(l4j(tt, "INFO", thr, "c.shop.checkout.InvoiceStep", f"Could not reach invoice-service, invoice for cart={cart} will NOT be generated"))
    elif i == 25:
        L.append(l4j(tt, "DEBUG", thr, "c.shop.checkout.TaxStep", f"Tax lookup failed for cart={cart}, falling back to rate 0.00 (timeout after 2000 ms)"))
    else:
        L.append(l4j(tt, "INFO", thr, "c.shop.checkout.CheckoutController", f"Checkout completed cart={cart} items={i % 4 + 1} total_eur={12.5 + i * 3.1:.2f}"))
    if i % 4 == 0:
        L.append(l4j(tt + timedelta(milliseconds=3), "DEBUG", thr, "c.shop.checkout.CartRepository", f"Loaded cart={cart} rows={i % 4 + 1} in 4 ms"))
    if i % 12 == 0:
        L.append(l4j(tt + timedelta(milliseconds=1), "TRACE", thr, "c.shop.checkout.CheckoutController", f"Entering checkout(cart={cart})"))
    if i % 3 == 1:
        L.append(l4j(tt + timedelta(milliseconds=9), "WARN", "cache-refresh", "c.shop.checkout.ProductCache", "Cache refresh skipped: previous refresh still running"))
t2 = t + timedelta(seconds=30 + 36 * 25 + 40)
L.append(l4j(t2, "INFO", "SpringApplicationShutdownHook", "c.shop.checkout.CheckoutApp", "Shutdown requested, draining 2 in-flight requests"))
L.append(l4j(t2 + timedelta(seconds=6), "INFO", "main", "c.shop.checkout.CheckoutApp", "Starting checkout-service v3.2.1 on chk-01 (PID 3388)"))
L.append(l4j(t2 + timedelta(seconds=9, milliseconds=402), "FATAL", "main", "c.shop.checkout.CheckoutApp", "Web server failed to start: port 8085 already in use, exiting"))
L.sort()
(root / "levels" / "checkout-service.log").write_text("\n".join(L) + "\n")

UNL = [
    "Order 20117 reserved 3 items in warehouse BLR-2",
    "Disk /var/lib/postgresql at 91% (threshold 90%)",
    "Could not open database connection after 3 attempts; request aborted",
    "Entering ReservationService.reserve(order=20117, sku=SKU-4410)",
    "Retrying call to ledger-api (attempt 2 of 3) after 503",
    "Out of memory: heap exhausted, JVM is shutting down",
    "Resolved 14 feature flags from config server in 38 ms",
    "Login failed for user 'reports' : wrong password",
    "Payment settlement batch 118 failed: ledger-api unreachable",
    "SQL: SELECT id, qty FROM stock WHERE sku = ? [SKU-4410]",
]
(root / "levels" / "unlabelled.txt").write_text("\n".join(f"{i + 1:>2}. {m}" for i, m in enumerate(UNL)) + "\n")

# ======================================================================== cascade/
# Story: the data disk of orders-db fills up. PostgreSQL fails, then crashes;
# inventory-service, orders-api and the gateway all report the consequences.
INV, PG, ORD, GW, DB = [], [], [], [], []

# --- background noise: statsd publisher has failed every 5 minutes since 10:00
for k in range(0, 24):
    tt = T(10, 0, 7) + timedelta(minutes=5 * k)
    INV.append((tt, l4j(tt, "ERROR", "metrics-publisher", "c.shop.metrics.StatsdPublisher", "Failed to send metrics to statsd:8125 (connection refused)")))

# --- normal traffic 10:58 - 11:02
okorders = [(T(10, 58, 2, 114), 20109), (T(10, 58, 40, 9), 20110), (T(10, 59, 21, 655), 20111), (T(11, 0, 3, 402), 20112),
            (T(11, 0, 47, 330), 20113), (T(11, 1, 12, 871), 20114), (T(11, 1, 39, 25), 20115), (T(11, 1, 58, 702), 20116)]
for n, (tt, oid) in enumerate(okorders):
    thr = f"http-nio-8081-exec-{n % 4 + 1}"
    ORD.append((tt, json.dumps({"ts": iso(tt), "level": "info", "service": "orders-api", "msg": "order received", "order_id": oid, "request_id": f"r-{oid}"})))
    INV.append((tt + timedelta(milliseconds=18), l4j(tt + timedelta(milliseconds=18), "INFO", thr, "c.shop.inventory.ReservationService", f"Reserved order={oid} items={n % 3 + 1} warehouse=BLR-2 request_id=r-{oid}")))
    ORD.append((tt + timedelta(milliseconds=64), json.dumps({"ts": iso(tt + timedelta(milliseconds=64)), "level": "info", "service": "orders-api", "msg": "order created", "order_id": oid, "status": 201, "duration_ms": 64, "request_id": f"r-{oid}"})))
    GW.append((tt + timedelta(milliseconds=70), (tt + timedelta(milliseconds=70), "POST /api/orders", 201, 0.070)))
    for j in range(3):
        g = tt + timedelta(seconds=4 + j * 6)
        GW.append((g, (g, ["GET /", "GET /product/1188", "GET /cart"][j], 200, 0.011 + j * 0.01)))

# --- db host disk warnings
DB.append((T(10, 52, 3), "Nov  6 10:52:03 orders-db disk-check[811]: WARNING /var/lib/postgresql usage 91% (threshold 90%)"))
DB.append((T(10, 57, 3), "Nov  6 10:57:03 orders-db disk-check[811]: WARNING /var/lib/postgresql usage 96% (threshold 90%)"))
DB.append((T(11, 2, 3), "Nov  6 11:02:03 orders-db disk-check[811]: WARNING /var/lib/postgresql usage 100% (threshold 90%)"))
DB.append((T(11, 0, 1), "Nov  6 11:00:01 orders-db CRON[1990]: (postgres) CMD (/usr/local/bin/pg-backup-local.sh)"))


def pg(tt, pid, lvl, msg):
    return (tt, f"{tt.strftime('%Y-%m-%d %H:%M:%S.')}{tt.microsecond // 1000:03d} UTC [{pid}] {lvl}:  {msg}")


PG.append(pg(T(10, 55, 0, 4), 1022, "LOG", "checkpoint starting: time"))
PG.append(pg(T(10, 55, 26, 870), 1022, "LOG", "checkpoint complete: wrote 1804 buffers (11.0%); 0 WAL file(s) added, 0 removed, 1 recycled"))
PG.append(pg(T(11, 0, 1, 230), 1991, "LOG", "connection authorized: user=backup database=orders application_name=pg_dump"))
PG.append(pg(T(11, 2, 14, 311), 2214, "ERROR", 'could not extend file "base/16384/16402": No space left on device'))
PG.append(pg(T(11, 2, 14, 311), 2214, "HINT", "Check free disk space."))
PG.append(pg(T(11, 2, 14, 311), 2214, "STATEMENT", "INSERT INTO stock_reservations (order_id, sku, qty, warehouse) VALUES ($1, $2, $3, $4)"))
PG.append(pg(T(11, 2, 31, 502), 2219, "PANIC", 'could not write to file "pg_wal/xlogtemp.2219": No space left on device'))
PG.append(pg(T(11, 2, 31, 640), 1011, "LOG", "server process (PID 2219) was terminated by signal 6: Aborted"))
PG.append(pg(T(11, 2, 31, 641), 1011, "LOG", "terminating any other active server processes"))
PG.append(pg(T(11, 2, 31, 702), 1011, "LOG", "all server processes terminated; reinitializing"))
PG.append(pg(T(11, 2, 31, 760), 2230, "LOG", "database system was interrupted; last known up at 2026-11-06 10:55:26 UTC"))
for k in range(9):
    tt = T(11, 2, 33, 100) + timedelta(seconds=3 * k, milliseconds=41 * k)
    PG.append(pg(tt, 2240 + k, "FATAL", "the database system is in recovery mode"))
PG.append(pg(T(11, 2, 58, 15), 2230, "PANIC", 'could not write to file "pg_wal/xlogtemp.2230": No space left on device'))
PG.append(pg(T(11, 2, 58, 120), 1011, "LOG", "startup process (PID 2230) was terminated by signal 6: Aborted"))
PG.append(pg(T(11, 2, 58, 121), 1011, "LOG", "aborting startup due to startup process failure"))
PG.append(pg(T(11, 2, 58, 133), 1011, "LOG", "database system is shut down"))

# --- the first failing order 20117
TRACE1 = """org.springframework.orm.jpa.JpaSystemException: could not execute statement; nested exception is org.hibernate.exception.GenericJDBCException: could not execute statement
	at org.springframework.orm.jpa.vendor.HibernateJpaDialect.convertHibernateAccessException(HibernateJpaDialect.java:331)
	at org.springframework.orm.jpa.vendor.HibernateJpaDialect.translateExceptionIfPossible(HibernateJpaDialect.java:233)
	at org.springframework.orm.jpa.JpaTransactionManager.doCommit(JpaTransactionManager.java:566)
	at org.springframework.transaction.support.AbstractPlatformTransactionManager.processCommit(AbstractPlatformTransactionManager.java:743)
	at org.springframework.transaction.interceptor.TransactionAspectSupport.invokeWithinTransaction(TransactionAspectSupport.java:388)
	at c.shop.inventory.ReservationService$$SpringCGLIB$$0.reserve(<generated>)
	at c.shop.inventory.ReservationController.create(ReservationController.java:33)
	at java.base/jdk.internal.reflect.DirectMethodHandleAccessor.invoke(DirectMethodHandleAccessor.java:103)
	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:885)
	at org.apache.tomcat.util.threads.TaskThread$WrappingRunnable.run(TaskThread.java:61)
	at java.base/java.lang.Thread.run(Thread.java:1583)
Caused by: org.hibernate.exception.GenericJDBCException: could not execute statement
	at org.hibernate.exception.internal.StandardSQLExceptionConverter.convert(StandardSQLExceptionConverter.java:63)
	at org.hibernate.engine.jdbc.spi.SqlExceptionHelper.convert(SqlExceptionHelper.java:108)
	at org.hibernate.engine.jdbc.internal.ResultSetReturnImpl.executeUpdate(ResultSetReturnImpl.java:197)
	at org.hibernate.persister.entity.AbstractEntityPersister.insert(AbstractEntityPersister.java:3375)
	at org.hibernate.internal.SessionImpl.flush(SessionImpl.java:1339)
	at c.shop.inventory.ReservationService.reserve(ReservationService.java:58)
	at org.springframework.orm.jpa.JpaTransactionManager.doCommit(JpaTransactionManager.java:562)
	... 74 more
Caused by: org.postgresql.util.PSQLException: ERROR: could not extend file "base/16384/16402": No space left on device
  Hint: Check free disk space.
	at org.postgresql.core.v3.QueryExecutorImpl.receiveErrorResponse(QueryExecutorImpl.java:2725)
	at org.postgresql.core.v3.QueryExecutorImpl.processResults(QueryExecutorImpl.java:2412)
	at org.postgresql.jdbc.PgPreparedStatement.executeUpdate(PgPreparedStatement.java:152)
	at com.zaxxer.hikari.pool.HikariProxyPreparedStatement.executeUpdate(HikariProxyPreparedStatement.java)
	at org.hibernate.engine.jdbc.internal.ResultSetReturnImpl.executeUpdate(ResultSetReturnImpl.java:194)
	... 79 more"""

TRACE2 = """org.springframework.transaction.CannotCreateTransactionException: Could not open JPA EntityManager for transaction
	at org.springframework.orm.jpa.JpaTransactionManager.doBegin(JpaTransactionManager.java:466)
	at org.springframework.transaction.support.AbstractPlatformTransactionManager.startTransaction(AbstractPlatformTransactionManager.java:531)
	at org.springframework.transaction.interceptor.TransactionAspectSupport.createTransactionIfNecessary(TransactionAspectSupport.java:595)
	at c.shop.inventory.ReservationService$$SpringCGLIB$$0.reserve(<generated>)
	at c.shop.inventory.ReservationController.create(ReservationController.java:33)
	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:885)
	at java.base/java.lang.Thread.run(Thread.java:1583)
Caused by: org.hibernate.exception.JDBCConnectionException: Unable to acquire JDBC Connection [HikariPool-1 - Connection is not available, request timed out after 30000ms.]
	at org.hibernate.exception.internal.SQLStateConversionDelegate.convert(SQLStateConversionDelegate.java:100)
	at org.hibernate.engine.jdbc.internal.LogicalConnectionManagedImpl.acquireConnectionIfNeeded(LogicalConnectionManagedImpl.java:113)
	at org.springframework.orm.jpa.JpaTransactionManager.doBegin(JpaTransactionManager.java:420)
	... 58 more
Caused by: java.sql.SQLTransientConnectionException: HikariPool-1 - Connection is not available, request timed out after 30000ms.
	at com.zaxxer.hikari.pool.HikariPool.createTimeoutException(HikariPool.java:696)
	at com.zaxxer.hikari.pool.HikariPool.getConnection(HikariPool.java:181)
	at com.zaxxer.hikari.HikariDataSource.getConnection(HikariDataSource.java:100)
	at org.hibernate.engine.jdbc.connections.internal.DatasourceConnectionProviderImpl.getConnection(DatasourceConnectionProviderImpl.java:122)
	... 61 more
Caused by: org.postgresql.util.PSQLException: FATAL: the database system is in recovery mode
	at org.postgresql.core.v3.ConnectionFactoryImpl.doAuthentication(ConnectionFactoryImpl.java:693)
	at org.postgresql.core.v3.ConnectionFactoryImpl.openConnectionImpl(ConnectionFactoryImpl.java:203)
	at org.postgresql.Driver.connect(Driver.java:297)
	at com.zaxxer.hikari.pool.PoolBase.newConnection(PoolBase.java:359)
	at com.zaxxer.hikari.pool.HikariPool$PoolEntryCreator.call(HikariPool.java:739)
	at java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1144)
	at java.base/java.lang.Thread.run(Thread.java:1583)"""

TRACE3 = """c.shop.inventory.export.ExportFailedException: Stock export failed for warehouse BLR-2
	at c.shop.inventory.export.StockExporter.export(StockExporter.java:57)
	at c.shop.inventory.export.ExportJob.run(ExportJob.java:28)
	at org.springframework.scheduling.support.ScheduledMethodRunnable.run(ScheduledMethodRunnable.java:84)
	at java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1144)
	at java.base/java.lang.Thread.run(Thread.java:1583)
Caused by: org.postgresql.util.PSQLException: An I/O error occurred while sending to the backend.
	at org.postgresql.core.v3.QueryExecutorImpl.execute(QueryExecutorImpl.java:395)
	at org.postgresql.jdbc.PgStatement.executeInternal(PgStatement.java:498)
	at org.postgresql.jdbc.PgStatement.executeQuery(PgStatement.java:236)
	at com.zaxxer.hikari.pool.HikariProxyStatement.executeQuery(HikariProxyStatement.java)
	at c.shop.inventory.export.StockExporter.export(StockExporter.java:49)
	... 4 more
	Suppressed: java.sql.SQLException: Connection is closed
		at com.zaxxer.hikari.pool.ProxyConnection$ClosedConnection.lambda$getClosedConnection$0(ProxyConnection.java:515)
		at jdk.proxy2/jdk.proxy2.$Proxy118.close(Unknown Source)
		at c.shop.inventory.export.StockExporter.export(StockExporter.java:46)
		... 4 more
Caused by: java.io.EOFException
	at org.postgresql.core.PGStream.receiveChar(PGStream.java:467)
	at org.postgresql.core.v3.QueryExecutorImpl.processResults(QueryExecutorImpl.java:2155)
	at org.postgresql.core.v3.QueryExecutorImpl.execute(QueryExecutorImpl.java:368)
	... 8 more"""

TRACE4 = """java.lang.NullPointerException: Cannot invoke "c.shop.inventory.Sku.getWarehouse()" because "sku" is null
	at c.shop.inventory.StockLookup.warehouseFor(StockLookup.java:77)
	at c.shop.inventory.StockLookup.available(StockLookup.java:41)
	at c.shop.inventory.StockController.get(StockController.java:29)
	at java.base/jdk.internal.reflect.DirectMethodHandleAccessor.invoke(DirectMethodHandleAccessor.java:103)
	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:885)
	at java.base/java.lang.Thread.run(Thread.java:1583)"""

tt = T(11, 0, 20, 88)
INV.append((tt, l4j(tt, "ERROR", "http-nio-8081-exec-2", "c.shop.inventory.StockController", "Stock lookup failed for sku=SKU-0000 request_id=r-s771") + "\n" + TRACE4))

t0 = T(11, 2, 14, 290)
ORD.append((t0 - timedelta(milliseconds=30), json.dumps({"ts": iso(t0 - timedelta(milliseconds=30)), "level": "info", "service": "orders-api", "msg": "order received", "order_id": 20117, "request_id": "r-20117"})))
INV.append((T(11, 2, 14, 318), l4j(T(11, 2, 14, 318), "WARN", "http-nio-8081-exec-3", "o.h.engine.jdbc.spi.SqlExceptionHelper", "SQL Error: 0, SQLState: 53100")))
INV.append((T(11, 2, 14, 319), l4j(T(11, 2, 14, 319), "ERROR", "http-nio-8081-exec-3", "o.h.engine.jdbc.spi.SqlExceptionHelper", 'ERROR: could not extend file "base/16384/16402": No space left on device')))
INV.append((T(11, 2, 14, 327), l4j(T(11, 2, 14, 327), "ERROR", "http-nio-8081-exec-3", "c.shop.inventory.ReservationController", "Reservation failed order=20117 request_id=r-20117") + "\n" + TRACE1))
ORD.append((T(11, 2, 14, 341), json.dumps({"ts": iso(T(11, 2, 14, 341)), "level": "error", "service": "orders-api", "msg": "inventory reservation failed", "order_id": 20117, "upstream": "inventory-service", "upstream_status": 500, "request_id": "r-20117"})))
ORD.append((T(11, 2, 14, 343), json.dumps({"ts": iso(T(11, 2, 14, 343)), "level": "info", "service": "orders-api", "msg": "order failed", "order_id": 20117, "status": 500, "duration_ms": 83, "request_id": "r-20117"})))
GW.append((T(11, 2, 14, 349), (T(11, 2, 14, 349), "POST /api/orders", 500, 0.089)))

# --- export job hits the crash
INV.append((T(11, 2, 31, 655), l4j(T(11, 2, 31, 655), "ERROR", "scheduling-1", "c.shop.inventory.export.ExportJob", "Scheduled export failed") + "\n" + TRACE3))
INV.append((T(11, 2, 31, 662), l4j(T(11, 2, 31, 662), "WARN", "HikariPool-1 housekeeper", "com.zaxxer.hikari.pool.PoolBase", "HikariPool-1 - Failed to validate connection org.postgresql.jdbc.PgConnection@5e1f2a (This connection has been closed.)")))

# --- the flood: every new order fails for ~30 s while the pool times out, then fast 503s from the circuit breaker
oid = 20118
for k in range(12):
    tt = (T(11, 2, 35, 0) + timedelta(seconds=2 * k, milliseconds=173 * k % 900)) if k < 5 else (T(11, 3, 14, 0) + timedelta(seconds=2 * (k - 5), milliseconds=173 * k % 900))
    thr = f"http-nio-8081-exec-{k % 8 + 1}"
    ORD.append((tt, json.dumps({"ts": iso(tt), "level": "info", "service": "orders-api", "msg": "order received", "order_id": oid, "request_id": f"r-{oid}"})))
    if k < 5:
        te = tt + timedelta(seconds=30, milliseconds=4)
        INV.append((te, l4j(te, "ERROR", thr, "c.shop.inventory.ReservationController", f"Reservation failed order={oid} request_id=r-{oid}") + ("\n" + TRACE2 if k == 0 else "")))
        if k == 0:
            INV.append((te - timedelta(milliseconds=2), l4j(te - timedelta(milliseconds=2), "WARN", thr, "com.zaxxer.hikari.pool.HikariPool", "HikariPool-1 - Connection is not available, request timed out after 30000ms.")))
        tr = te + timedelta(milliseconds=12)
        ORD.append((tr, json.dumps({"ts": iso(tr), "level": "error", "service": "orders-api", "msg": "inventory reservation failed", "order_id": oid, "upstream": "inventory-service", "upstream_status": 500, "request_id": f"r-{oid}"})))
        GW.append((tr + timedelta(milliseconds=5), (tr + timedelta(milliseconds=5), "POST /api/orders", 504 if k < 2 else 500, 30.021)))
    else:
        if k == 5:
            ORD.append((tt + timedelta(milliseconds=1), json.dumps({"ts": iso(tt + timedelta(milliseconds=1)), "level": "warn", "service": "orders-api", "msg": "circuit breaker OPEN for inventory-service after 5 consecutive failures", "breaker": "inventory"})))
        tr = tt + timedelta(milliseconds=2)
        ORD.append((tr, json.dumps({"ts": iso(tr), "level": "error", "service": "orders-api", "msg": "inventory unavailable (circuit open)", "order_id": oid, "status": 503, "request_id": f"r-{oid}"})))
        GW.append((tr + timedelta(milliseconds=4), (tr + timedelta(milliseconds=4), "POST /api/orders", 503, 0.006)))
    oid += 1
for k in range(6):
    g = T(11, 2, 40) + timedelta(seconds=7 * k)
    GW.append((g, (g, ["GET /", "GET /cart", "GET /product/2210"][k % 3], 200, 0.012)))

for name, rows in (("inventory-service.log", INV), ("postgresql.log", PG), ("db-host-syslog.log", DB)):
    rows.sort(key=lambda r: r[0])
    (root / "cascade" / name).write_text("\n".join(r[1] for r in rows) + "\n")
ORD.sort(key=lambda r: r[0])
(root / "cascade" / "orders-api.json").write_text("\n".join(r[1] for r in ORD) + "\n")
GW.sort(key=lambda r: r[0])
with open(root / "cascade" / "gateway-access.log", "w") as f:
    for _, (g, req, st, rt) in GW:
        f.write(f'198.51.100.{60 + int(g.second) % 30} - - [{g.strftime("%d/%b/%Y:%H:%M:%S")} +0000] "{req} HTTP/1.1" {st} {120 if st >= 500 else 512} "-" "Mozilla/5.0" {rt:.3f}\n')

# ======================================================================== java/
(root / "java" / "trace-1-reservation.txt").write_text(TRACE1 + "\n")
(root / "java" / "trace-2-pool-timeout.txt").write_text(TRACE2 + "\n")
(root / "java" / "trace-3-export-suppressed.txt").write_text(TRACE3 + "\n")
(root / "java" / "trace-4-npe.txt").write_text(TRACE4 + "\n")

# ======================================================================== dotnet/
NET1 = """System.InvalidOperationException: Invoice 88231 could not be finalised
 ---> System.Net.Http.HttpRequestException: Connection refused (tax-api:443)
 ---> System.Net.Sockets.SocketException (111): Connection refused
   at System.Net.Sockets.Socket.AwaitableSocketAsyncEventArgs.ThrowException(SocketError error, CancellationToken cancellationToken)
   at System.Net.Sockets.Socket.AwaitableSocketAsyncEventArgs.System.Threading.Tasks.Sources.IValueTaskSource.GetResult(Int16 token)
   at System.Net.Sockets.Socket.<ConnectAsync>g__WaitForConnectWithCancellation|285_0(AwaitableSocketAsyncEventArgs saea, ValueTask connectTask, CancellationToken cancellationToken)
   at System.Net.Http.HttpConnectionPool.ConnectToTcpHostAsync(String host, Int32 port, HttpRequestMessage initialRequest, Boolean async, CancellationToken cancellationToken)
   --- End of inner exception stack trace ---
   at System.Net.Http.HttpConnectionPool.ConnectToTcpHostAsync(String host, Int32 port, HttpRequestMessage initialRequest, Boolean async, CancellationToken cancellationToken)
   at System.Net.Http.HttpConnectionPool.ConnectAsync(HttpRequestMessage request, Boolean async, CancellationToken cancellationToken)
   at System.Net.Http.HttpClient.<SendAsync>g__Core|83_0(HttpRequestMessage request, HttpCompletionOption completionOption, CancellationTokenSource cts, Boolean disposeCts, CancellationTokenSource pendingRequestsCts, CancellationToken originalCancellationToken)
   at Shop.Billing.Tax.TaxClient.GetRateAsync(String region) in /src/Shop.Billing/Tax/TaxClient.cs:line 42
   at Shop.Billing.Invoices.InvoiceService.FinaliseAsync(Int32 invoiceId) in /src/Shop.Billing/Invoices/InvoiceService.cs:line 87
   --- End of inner exception stack trace ---
   at Shop.Billing.Invoices.InvoiceService.FinaliseAsync(Int32 invoiceId) in /src/Shop.Billing/Invoices/InvoiceService.cs:line 95
   at Shop.Billing.Api.InvoicesController.Finalise(Int32 id) in /src/Shop.Billing/Api/InvoicesController.cs:line 31
   at lambda_method12(Closure, Object)
   at Microsoft.AspNetCore.Mvc.Infrastructure.ActionMethodExecutor.AwaitableObjectResultExecutor.Execute(ActionContext actionContext, IActionResultTypeMapper mapper, ObjectMethodExecutor executor, Object controller, Object[] arguments)
--- End of stack trace from previous location ---
   at Microsoft.AspNetCore.Mvc.Infrastructure.ControllerActionInvoker.<InvokeActionMethodAsync>g__Logged|12_1(ControllerActionInvoker invoker)
   at Microsoft.AspNetCore.Routing.EndpointMiddleware.<Invoke>g__AwaitRequestTask|7_0(Endpoint endpoint, Task requestTask, ILogger logger)"""

NET2 = """Microsoft.EntityFrameworkCore.DbUpdateException: An error occurred while saving the entity changes. See the inner exception for details.
 ---> Npgsql.PostgresException (0x80004005): 53100: could not extend file "base/16384/16511": No space left on device

DETAIL: Detail redacted as it may contain sensitive data. Specify 'Include Error Detail' in the connection string to include this information.
   at Npgsql.Internal.NpgsqlConnector.ReadMessageLong(Boolean async, DataRowLoadingMode dataRowLoadingMode, Boolean readingNotifications, Boolean isReadingPrependedMessage)
   at Npgsql.NpgsqlDataReader.NextResult(Boolean async, Boolean isConsuming, CancellationToken cancellationToken)
   at Npgsql.NpgsqlCommand.ExecuteReader(Boolean async, CommandBehavior behavior, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.Update.ReaderModificationCommandBatch.ExecuteAsync(IRelationalConnection connection, CancellationToken cancellationToken)
  Exception data:
    Severity: ERROR
    SqlState: 53100
    MessageText: could not extend file "base/16384/16511": No space left on device
    Hint: Check free disk space.
    File: md.c
    Line: 535
    Routine: mdextend
   --- End of inner exception stack trace ---
   at Microsoft.EntityFrameworkCore.Update.ReaderModificationCommandBatch.ExecuteAsync(IRelationalConnection connection, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.Update.Internal.BatchExecutor.ExecuteAsync(IEnumerable`1 commandBatches, IRelationalConnection connection, CancellationToken cancellationToken)
   at Microsoft.EntityFrameworkCore.DbContext.SaveChangesAsync(Boolean acceptAllChangesOnSuccess, CancellationToken cancellationToken)
   at Shop.Billing.Invoices.InvoiceRepository.SaveAsync(Invoice invoice) in /src/Shop.Billing/Invoices/InvoiceRepository.cs:line 26
   at Shop.Billing.Invoices.InvoiceService.CreateAsync(CreateInvoice cmd) in /src/Shop.Billing/Invoices/InvoiceService.cs:line 54
   at Shop.Billing.Api.InvoicesController.Create(CreateInvoice cmd) in /src/Shop.Billing/Api/InvoicesController.cs:line 22"""

NET3 = """System.AggregateException: One or more errors occurred. (Timeout calling ledger-api after 10 seconds) (Response status code does not indicate success: 503 (Service Unavailable).)
 ---> System.TimeoutException: Timeout calling ledger-api after 10 seconds
   at Shop.Billing.Ledger.LedgerClient.PostAsync(LedgerEntry entry) in /src/Shop.Billing/Ledger/LedgerClient.cs:line 58
   at Shop.Billing.Settlement.SettlementJob.SettleAsync(Int32 batchId, LedgerEntry entry) in /src/Shop.Billing/Settlement/SettlementJob.cs:line 44
   --- End of inner exception stack trace ---
   at System.Threading.Tasks.Task.ThrowIfExceptional(Boolean includeTaskCanceledExceptions)
   at System.Threading.Tasks.Task.Wait(Int32 millisecondsTimeout, CancellationToken cancellationToken)
   at Shop.Billing.Settlement.SettlementJob.Run(Int32 batchId) in /src/Shop.Billing/Settlement/SettlementJob.cs:line 29
 ---> (Inner Exception #1) System.Net.Http.HttpRequestException: Response status code does not indicate success: 503 (Service Unavailable).
   at System.Net.Http.HttpResponseMessage.EnsureSuccessStatusCode()
   at Shop.Billing.Ledger.LedgerClient.PostAsync(LedgerEntry entry) in /src/Shop.Billing/Ledger/LedgerClient.cs:line 61
   at Shop.Billing.Settlement.SettlementJob.SettleAsync(Int32 batchId, LedgerEntry entry) in /src/Shop.Billing/Settlement/SettlementJob.cs:line 44<---"""

SER = []


def ser(t, lvl, ctx, msg, exc=None):
    s = f"{t.strftime('%Y-%m-%d %H:%M:%S.')}{t.microsecond // 1000:03d} +00:00 [{lvl}] {ctx}: {msg}"
    return s + ("\n" + exc if exc else "")


SER.append(ser(T(10, 59, 0, 5), "INF", "Microsoft.Hosting.Lifetime", "Now listening on: http://[::]:8080"))
SER.append(ser(T(10, 59, 0, 9), "INF", "Microsoft.Hosting.Lifetime", "Application started. Press Ctrl+C to shut down."))
SER.append(ser(T(11, 0, 12, 340), "INF", "Shop.Billing.Invoices.InvoiceService", "Invoice 88229 created for order 20112 total_eur=48.20"))
SER.append(ser(T(11, 0, 12, 341), "DBG", "Shop.Billing.Tax.TaxClient", "Tax rate for region KA cached for 300 s"))
SER.append(ser(T(11, 1, 45, 902), "WRN", "Shop.Billing.Tax.TaxClient", "tax-api responded slowly (1840 ms), using cached rate for region KA"))
SER.append(ser(T(11, 1, 59, 105), "INF", "Shop.Billing.Invoices.InvoiceService", "Invoice 88230 created for order 20116 total_eur=31.70"))
SER.append(ser(T(11, 2, 16, 204), "ERR", "Shop.Billing.Invoices.InvoiceService", "Failed to create invoice for order 20115", NET2))
SER.append(ser(T(11, 2, 40, 18), "ERR", "Shop.Billing.Api.InvoicesController", "Finalise failed for invoice 88231", NET1))
SER.append(ser(T(11, 3, 0, 2), "ERR", "Shop.Billing.Settlement.SettlementJob", "Settlement batch 118 failed", NET3))
SER.append(ser(T(11, 3, 0, 9), "FTL", "Shop.Billing.Settlement.SettlementJob", "Settlement worker stopping after 3 consecutive batch failures"))
(root / "dotnet" / "billing.log").write_text("\n".join(SER) + "\n")

CLEF = [
    {"@t": "2026-11-06T11:00:12.3400000Z", "@mt": "Invoice {InvoiceId} created for order {OrderId}", "InvoiceId": 88229, "OrderId": 20112, "SourceContext": "Shop.Billing.Invoices.InvoiceService"},
    {"@t": "2026-11-06T11:01:45.9020000Z", "@mt": "tax-api responded slowly ({ElapsedMs} ms), using cached rate for region {Region}", "@l": "Warning", "ElapsedMs": 1840, "Region": "KA", "SourceContext": "Shop.Billing.Tax.TaxClient"},
    {"@t": "2026-11-06T11:02:16.2040000Z", "@mt": "Failed to create invoice for order {OrderId}", "@l": "Error", "@x": NET2, "OrderId": 20115, "SourceContext": "Shop.Billing.Invoices.InvoiceService"},
    {"@t": "2026-11-06T11:02:40.0180000Z", "@mt": "Finalise failed for invoice {InvoiceId}", "@l": "Error", "@x": NET1, "InvoiceId": 88231, "SourceContext": "Shop.Billing.Api.InvoicesController"},
    {"@t": "2026-11-06T11:03:00.0020000Z", "@mt": "Settlement batch {BatchId} failed", "@l": "Error", "@x": NET3, "BatchId": 118, "SourceContext": "Shop.Billing.Settlement.SettlementJob"},
    {"@t": "2026-11-06T11:03:00.0090000Z", "@mt": "Settlement worker stopping after {Failures} consecutive batch failures", "@l": "Fatal", "Failures": 3, "SourceContext": "Shop.Billing.Settlement.SettlementJob"},
]
(root / "dotnet" / "billing.clef.json").write_text("\n".join(json.dumps(r) for r in CLEF) + "\n")

print(f"Part 2 sample logs written to {root}")
for d in ("levels", "cascade", "java", "dotnet"):
    for p in sorted((root / d).iterdir()):
        print(f"  {p.relative_to(root)}")
