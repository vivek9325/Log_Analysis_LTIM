#!/usr/bin/env python3
"""Add the Day 1 Part 4 sample logs to the lab pack (~/day1-logs/trace).

Seven components of a small shop, 10:14 to 10:16:30 UTC on 6 Nov 2026:
  gateway.log          Nginx with ngx_otel_module   (trace=, span=, cid=)
  orders-service.log   Java, Logback + MDC          ([traceId= spanId= cid=])
  inventory.log        logfmt                       (trace_id= span_id= cid=)
  payments.log         JSON Lines                   ("trace_id", "span_id", "cid")
  fraud-check.log      Python logging               (trace_id= span_id=, no cid)
  shipping-worker.log  Java Kafka consumer + MDC    ([traceId= spanId= cid=])
  postgres.log         PostgreSQL, log_line_prefix '%m [%p] %a ', sqlcommenter
  spans.json           the same transactions as OpenTelemetry-style spans
Everything is invented and deterministic: the same files every run.
Run:  python3 make_day1_part4.py [target-dir]      (default: ~/day1-logs)
"""
import json
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "day1-logs")
out = root / "trace"
out.mkdir(parents=True, exist_ok=True)
rnd = random.Random(20261106 + 4)
UTC = timezone.utc
BASE = datetime(2026, 11, 6, 10, 0, 0, tzinfo=UTC)


def T(s):                       # seconds after 10:00:00 -> datetime
    return BASE + timedelta(seconds=s)


def hexid(n):
    return "".join(rnd.choice("0123456789abcdef") for _ in range(n))


def iso(s):                     # 2026-11-06T10:15:01.903Z
    t = T(s)
    return t.strftime("%Y-%m-%dT%H:%M:%S.") + f"{t.microsecond // 1000:03d}Z"


def java_ts(s):                 # 2026-11-06 10:15:01,903
    t = T(s)
    return t.strftime("%Y-%m-%d %H:%M:%S,") + f"{t.microsecond // 1000:03d}"


def pg_ts(s):                   # 2026-11-06 10:15:06.787 UTC
    t = T(s)
    return t.strftime("%Y-%m-%d %H:%M:%S.") + f"{t.microsecond // 1000:03d} UTC"


def nginx_ts(s):                # [2026-11-06T10:15:06+00:00]  ($time_iso8601: whole seconds)
    return T(s).strftime("%Y-%m-%dT%H:%M:%S+00:00")


def uuid4():
    h = hexid(32)
    return f"{h[:8]}-{h[8:12]}-4{h[13:16]}-{'89ab'[int(h[16], 16) % 4]}{h[17:20]}-{h[20:32]}"


logs = {k: [] for k in ["gateway", "orders", "inventory", "payments", "fraud", "shipping", "postgres"]}
spans = []
CLIENTS = [f"198.51.100.{n}" for n in range(20, 60)]
SKUS = ["KB-104", "MS-220", "HD-310", "CB-055", "DK-700", "LM-018", "BP-412"]
PRICES = {"KB-104": 89.90, "MS-220": 40.00, "HD-310": 129.00, "CB-055": 12.50, "DK-700": 349.00,
          "LM-018": 24.90, "BP-412": 59.00}
exec_n = [0]
pid_by_app = {"fraud-check": 21877, "orders-service": 21903, "inventory": 21911}


def span(trace, parent, service, name, kind, s0, s1, status="OK", attrs=None, events=None, sid=None):
    sid = sid or hexid(16)
    spans.append({"trace_id": trace, "span_id": sid, "parent_span_id": parent, "service": service,
                  "name": name, "kind": kind, "start": iso(s0), "end": iso(s1),
                  "duration_ms": round((s1 - s0) * 1000), "status": status,
                  "attributes": attrs or {}, "events": events or []})
    return sid


def jline(s, level, thread, tr, sp, cid, logger, msg):
    return (s, f"{java_ts(s)} {level:<5} [{thread}] [traceId={tr} spanId={sp} cid={cid}] {logger} - {msg}")


def gw(s_end, ip, method, path, status, size, rt, urt, cid, tr, sp):
    up = f"{urt:.3f}" if urt is not None else "-"
    logs["gateway"].append((s_end, f'{ip} - - [{nginx_ts(s_end)}] "{method} {path} HTTP/1.1" {status} {size} '
                                   f'rt={rt:.3f} urt={up} cid={cid} trace={tr} span={sp}'))


def inv(s, level, tr, sp, cid, msg, **kv):
    extra = "".join(f" {k}={v}" for k, v in kv.items())
    logs["inventory"].append((s, f'ts={iso(s)} level={level} svc=inventory trace_id={tr} span_id={sp} cid={cid} '
                                 f'msg="{msg}"{extra}'))


def pay(s, level, tr, sp, cid, msg, **kv):
    d = {"ts": iso(s), "level": level, "service": "payments", "trace_id": tr, "span_id": sp, "cid": cid, "msg": msg}
    d.update(kv)
    logs["payments"].append((s, json.dumps(d)))


def fr(s, level, tr, sp, msg):
    t = T(s)
    ts = t.strftime("%Y-%m-%d %H:%M:%S,") + f"{t.microsecond // 1000:03d}"
    logs["fraud"].append((s, f"{ts} {level} fraud_check.api trace_id={tr} span_id={sp} {msg}"))


def pg(s, app, ms, sql, tr, sp, params):
    pid = pid_by_app[app]
    tp = f"/*traceparent='00-{tr}-{sp}-01'*/"
    logs["postgres"].append((s, f"{pg_ts(s)} [{pid}] {app} LOG:  duration: {ms:.3f} ms  execute <unnamed>: {sql} {tp}"))
    logs["postgres"].append((s + 0.0000001, f"{pg_ts(s)} [{pid}] {app} DETAIL:  parameters: {params}"))


FRAUD_SQL = ("SELECT count(*), max(amount) FROM card_history WHERE card_hash = $1 "
             "AND created_at > now() - interval '90 days'")
INSERT_SQL = "INSERT INTO orders (id, customer_ref, total, status) VALUES ($1, $2, $3, 'PLACED')"
kafka_offset = [48190]


def checkout(s0, order, items, cid=None, ip=None, fraud_ms=None, outcome="ok", trace=None,
             insert_ms=None, retry_note=False):
    """One POST /api/checkout. outcome: ok | fraud_timeout | out_of_stock"""
    ip = ip or rnd.choice(CLIENTS)
    cid = cid or uuid4()
    tr = trace or hexid(32)
    total = round(sum(PRICES[k] for k in items), 2)
    thread = f"http-nio-8080-exec-{rnd.randint(1, 10)}"
    gsp, osp, isp, psp, fsp, dsp = (hexid(16) for _ in range(6))
    a = s0 + 0.003
    oj = []
    oj.append(jline(a, "INFO", thread, tr, osp, cid, "c.e.orders.CheckoutController",
                    f"POST /api/checkout order={order} items={len(items)} total={total:.2f}"))
    # inventory reserve
    i0 = a + 0.009 + rnd.randint(0, 4) / 1000
    if outcome == "out_of_stock":
        i1 = i0 + 0.021
        inv(i0, "info", tr, isp, cid, "reserve", order=order, skus=",".join(items))
        inv(i1, "warn", tr, isp, cid, "insufficient stock", order=order, sku=items[-1], available=0, status=409)
        span(tr, osp, "inventory", "POST /reserve", "SERVER", i0, i1 + 0.001, "OK",
             {"http.status_code": 409, "order.id": order, "error.reason": "OUT_OF_STOCK"}, sid=isp)
        e = i1 + 0.006
        oj.append(jline(e, "WARN", thread, tr, osp, cid, "c.e.orders.CheckoutService",
                        f"checkout rejected order={order} reason=OUT_OF_STOCK sku={items[-1]}"))
        e2 = e + 0.003
        span(tr, gsp, "orders-service", "POST /api/checkout", "SERVER", a, e2, "OK",
             {"http.status_code": 409, "order.id": order}, sid=osp)
        span(tr, None, "gateway", "POST /api/checkout", "SERVER", s0, e2 + 0.002, "OK",
             {"http.status_code": 409, "client.address": ip, "correlation.id": cid}, sid=gsp)
        gw(e2 + 0.002, ip, "POST", "/api/checkout", 409, 61, e2 + 0.002 - s0, e2 + 0.001 - s0 - 0.001, cid, tr, gsp)
        logs["orders"].extend(oj)
        return tr, cid
    i1 = i0 + (rnd.randint(18, 34) / 1000)
    inv(i0, "info", tr, isp, cid, "reserve", order=order, skus=",".join(items))
    inv(i1, "info", tr, isp, cid, "reserved", order=order, reservation=f"R-{order}", ttl_s=600)
    span(tr, osp, "inventory", "POST /reserve", "SERVER", i0, i1 + 0.001, "OK",
         {"http.status_code": 200, "order.id": order}, sid=isp)
    oj.append(jline(i1 + 0.002, "INFO", thread, tr, osp, cid, "c.e.orders.InventoryClient",
                    f"reserved order={order} skus={','.join(items)}"))
    # payments -> fraud-check -> postgres
    p0 = i1 + 0.008
    oj.append(jline(p0 - 0.002, "INFO", thread, tr, osp, cid, "c.e.orders.PaymentsClient",
                    f"authorise order={order} amount={total:.2f}"))
    pay(p0, "INFO", tr, psp, cid, "authorise start", order=order, amount=f"{total:.2f}", currency="EUR")
    f0 = p0 + 0.007
    pay(f0 - 0.001, "INFO", tr, psp, cid, "calling fraud-check", order=order, timeout_ms=4000)
    card = hexid(8)
    if order == 88123:
        card = "82b8f53c"           # the retry pays with the same card as the first attempt
    fr(f0 + 0.002, "INFO", tr, fsp, f"score request order={order} card=h:{card}")
    q0 = f0 + 0.009
    fms = fraud_ms if fraud_ms is not None else rnd.randint(22, 140) + rnd.random()
    q1 = q0 + fms / 1000
    span(tr, fsp, "fraud-check", "SELECT card_history", "CLIENT", q0, q1, "OK",
         {"db.system": "postgresql", "db.name": "shop", "db.operation": "SELECT", "db.sql.table": "card_history"},
         sid=dsp)
    if fms >= 250:
        pg(q1, "fraud-check", fms, FRAUD_SQL, tr, dsp, f"$1 = 'h:{hexid(12)}'")
    score = rnd.randint(3, 30)
    f1 = q1 + 0.011
    fr(f1, "INFO", tr, fsp, f"score={score} decision=approve order={order} elapsed_ms={round((f1 - f0) * 1000)}")
    if outcome == "fraud_timeout":
        pt = f0 + 4.000
        pay(pt, "ERROR", tr, psp, cid, "fraud-check timed out", order=order, timeout_ms=4000,
            error="java.net.http.HttpTimeoutException: request timed out")
        p1 = pt + 0.004
        pay(p1, "ERROR", tr, psp, cid, "authorise failed", order=order, status=502, elapsed_ms=round((p1 - p0) * 1000))
        fr(f1 + 0.027, "WARNING", tr, fsp,
           f"client disconnected before response was sent order={order} elapsed_ms={round((f1 + 0.027 - f0) * 1000)}")
        span(tr, psp, "fraud-check", "POST /score", "SERVER", f0, f1 + 0.027, "ERROR",
             {"http.status_code": 200, "order.id": order},
             [{"name": "exception", "time": iso(f1 + 0.027), "message": "client disconnected (broken pipe)"}], sid=fsp)
        span(tr, osp, "payments", "POST /authorise", "SERVER", p0, p1 + 0.001, "ERROR",
             {"http.status_code": 502, "order.id": order},
             [{"name": "exception", "time": iso(pt), "message": "HttpTimeoutException: fraud-check timed out after 4000 ms"}],
             sid=psp)
        e = p1 + 0.006
        oj.append(jline(e, "ERROR", thread, tr, osp, cid, "c.e.orders.PaymentsClient",
                        f"authorise failed order={order} status=502 elapsed_ms={round((e - p0 + 0.002) * 1000)}"))
        oj.append((e + 0.0000001, 'org.springframework.web.client.HttpServerErrorException$BadGateway: '
                                  '502 Bad Gateway: "{"error":"fraud-check timeout","timeout_ms":4000}"'))
        oj.append((e + 0.0000002, "\tat c.e.orders.PaymentsClient.authorise(PaymentsClient.java:61)"))
        oj.append((e + 0.0000003, "\tat c.e.orders.CheckoutService.placeOrder(CheckoutService.java:88)"))
        r0 = e + 0.012
        oj.append(jline(r0, "WARN", thread, tr, osp, cid, "c.e.orders.CheckoutService",
                        f"releasing reservation order={order} reason=payment_failed"))
        rsp = hexid(16)
        inv(r0 + 0.004, "info", tr, rsp, cid, "release", order=order, reservation=f"R-{order}")
        inv(r0 + 0.019, "info", tr, rsp, cid, "released", order=order, reservation=f"R-{order}")
        span(tr, osp, "inventory", "POST /release", "SERVER", r0 + 0.004, r0 + 0.020, "OK",
             {"http.status_code": 200, "order.id": order}, sid=rsp)
        e2 = r0 + 0.028
        oj.append(jline(e2, "ERROR", thread, tr, osp, cid, "c.e.orders.CheckoutController",
                        f"checkout failed order={order} status=502 reason=payment_unavailable"))
        span(tr, gsp, "orders-service", "POST /api/checkout", "SERVER", a, e2 + 0.001, "ERROR",
             {"http.status_code": 502, "order.id": order},
             [{"name": "exception", "time": iso(e), "message": "HttpServerErrorException$BadGateway: 502 from payments"}],
             sid=osp)
        g1 = e2 + 0.003
        span(tr, None, "gateway", "POST /api/checkout", "SERVER", s0, g1, "ERROR",
             {"http.status_code": 502, "client.address": ip, "correlation.id": cid}, sid=gsp)
        gw(g1, ip, "POST", "/api/checkout", 502, 157, g1 - s0, g1 - s0 - 0.002, cid, tr, gsp)
        logs["orders"].extend(oj)
        return tr, cid
    span(tr, psp, "fraud-check", "POST /score", "SERVER", f0, f1 + 0.002, "OK",
         {"http.status_code": 200, "order.id": order}, sid=fsp)
    p1 = f1 + 0.012
    pay(p1, "INFO", tr, psp, cid, "authorised", order=order, auth_code=f"A{rnd.randint(100000, 999999)}",
        elapsed_ms=round((p1 - p0) * 1000))
    span(tr, osp, "payments", "POST /authorise", "SERVER", p0, p1 + 0.001, "OK",
         {"http.status_code": 200, "order.id": order}, sid=psp)
    # orders: insert + publish
    d0 = p1 + 0.005
    ims = insert_ms if insert_ms is not None else rnd.randint(4, 19) + rnd.random()
    d1 = d0 + ims / 1000
    isp2 = hexid(16)
    span(tr, osp, "orders-service", "INSERT orders", "CLIENT", d0, d1, "OK",
         {"db.system": "postgresql", "db.name": "shop", "db.operation": "INSERT", "db.sql.table": "orders"}, sid=isp2)
    if ims >= 250:
        pg(d1, "orders-service", ims, INSERT_SQL, tr, isp2, f"$1 = '{order}', $2 = 'cust-{hexid(6)}', $3 = '{total:.2f}'")
    kafka_offset[0] += rnd.randint(1, 3)
    off = kafka_offset[0]
    part = order % 3
    k0 = d1 + 0.003
    ksp = hexid(16)
    oj.append(jline(k0 + 0.002, "INFO", thread, tr, osp, cid, "c.e.orders.EventPublisher",
                    f"published topic=orders.placed partition={part} offset={off} key={order}"))
    span(tr, osp, "orders-service", "orders.placed publish", "PRODUCER", k0, k0 + 0.002, "OK",
         {"messaging.system": "kafka", "messaging.destination.name": "orders.placed",
          "messaging.kafka.partition": part, "messaging.kafka.offset": off, "messaging.kafka.message.key": str(order)},
         sid=ksp)
    e2 = k0 + 0.006
    oj.append(jline(e2, "INFO", thread, tr, osp, cid, "c.e.orders.CheckoutController",
                    f"checkout complete order={order} status=201 elapsed_ms={round((e2 - a) * 1000)}"))
    span(tr, gsp, "orders-service", "POST /api/checkout", "SERVER", a, e2 + 0.001, "OK",
         {"http.status_code": 201, "order.id": order}, sid=osp)
    g1 = e2 + 0.003
    span(tr, None, "gateway", "POST /api/checkout", "SERVER", s0, g1, "OK",
         {"http.status_code": 201, "client.address": ip, "correlation.id": cid}, sid=gsp)
    gw(g1, ip, "POST", "/api/checkout", 201, 88, g1 - s0, g1 - s0 - 0.002, cid, tr, gsp)
    logs["orders"].extend(oj)
    # shipping-worker consumes later (consumer lag), label work on a pool thread loses the MDC
    c0 = g1 + rnd.randint(90, 260) / 1000
    csp = hexid(16)
    c1 = c0 + rnd.randint(110, 190) / 1000
    sh = logs["shipping"]
    sh.append(jline(c0, "INFO", "kafka-consumer-1", tr, csp, cid, "c.e.ship.OrderPlacedListener",
                    f"received topic=orders.placed partition={part} offset={off} key={order} lag_ms={round((c0 - k0) * 1000)}"))
    sh.append(jline(c1, "INFO", "kafka-consumer-1", tr, csp, cid, "c.e.ship.ShipmentService",
                    f"shipment created order={order} shipment=S-{order} carrier=ParcelCo"))
    lt = c1 + rnd.randint(250, 420) / 1000
    sh.append(jline(lt, "INFO", "label-pool-1", "", "", "", "c.e.ship.LabelPrinter",
                    f"label printed shipment=S-{order} order={order} pages=1"))
    span(tr, ksp, "shipping-worker", "orders.placed process", "CONSUMER", c0, c1 + 0.001, "OK",
         {"messaging.system": "kafka", "messaging.destination.name": "orders.placed",
          "messaging.kafka.partition": part, "messaging.kafka.offset": off, "messaging.kafka.message.key": str(order)},
         sid=csp)
    return tr, cid


def stock(s0, sku):
    ip = rnd.choice(CLIENTS)
    cid, tr, gsp, isp = uuid4(), hexid(32), hexid(16), hexid(16)
    i0 = s0 + 0.002
    i1 = i0 + rnd.randint(3, 11) / 1000
    inv(i0, "info", tr, isp, cid, "stock lookup", sku=sku)
    inv(i1, "info", tr, isp, cid, "stock", sku=sku, available=rnd.randint(1, 40))
    span(tr, gsp, "inventory", f"GET /stock/{{sku}}", "SERVER", i0, i1 + 0.001, "OK",
         {"http.status_code": 200, "sku": sku}, sid=isp)
    g1 = i1 + 0.003
    span(tr, None, "gateway", "GET /api/products/{sku}/stock", "SERVER", s0, g1, "OK",
         {"http.status_code": 200, "client.address": ip, "correlation.id": cid}, sid=gsp)
    gw(g1, ip, "GET", f"/api/products/{sku}/stock", 200, rnd.randint(40, 60), g1 - s0, g1 - s0 - 0.002, cid, tr, gsp)


def order_lookup(s0, order):
    ip = rnd.choice(CLIENTS)
    cid, tr, gsp, osp = uuid4(), hexid(32), hexid(16), hexid(16)
    thread = f"http-nio-8080-exec-{rnd.randint(1, 10)}"
    a = s0 + 0.002
    e = a + rnd.randint(4, 16) / 1000
    logs["orders"].append(jline(a, "INFO", thread, tr, osp, cid, "c.e.orders.OrderController",
                                f"GET /api/orders/{order}"))
    logs["orders"].append(jline(e, "INFO", thread, tr, osp, cid, "c.e.orders.OrderController",
                                f"order={order} status=PLACED elapsed_ms={round((e - a) * 1000)}"))
    span(tr, gsp, "orders-service", "GET /api/orders/{id}", "SERVER", a, e + 0.001, "OK",
         {"http.status_code": 200, "order.id": order}, sid=osp)
    g1 = e + 0.003
    span(tr, None, "gateway", "GET /api/orders/{id}", "SERVER", s0, g1, "OK",
         {"http.status_code": 200, "client.address": ip, "correlation.id": cid}, sid=gsp)
    gw(g1, ip, "GET", f"/api/orders/{order}", 200, rnd.randint(300, 420), g1 - s0, g1 - s0 - 0.002, cid, tr, gsp)


# ------------------------------------------------------------------ the story
# fixed IDs for the transactions the labs follow
CID = "3c9e7a1d-6b2f-4e58-a0d4-91f27c5b8e63"
TR_FAIL = "4f1c9a7e2b6d4e0f9a3c5b7d1e2f4a68"
TR_RETRY = "b83d2e6f1a9c4b57a0e4d6c8f2b1e397"
CUSTOMER_IP = "203.0.113.45"

events = []        # (start seconds, callable)
s = 14 * 60 + 2.0
order_no = 88118
slow_fraud = {88122: 312.418, 88126: 548.902, 88129: 884.137, 88131: 1263.550}
while s < 16 * 60 + 28:
    kind = rnd.choices(["checkout", "stock", "lookup"], [5, 4, 3])[0]
    if kind == "checkout":
        order_no += 1
        if order_no in (88123, 88127):
            order_no += 1
        n = order_no
        items = rnd.sample(SKUS, rnd.randint(1, 3))
        fm = slow_fraud.get(n)
        ins = 271.336 if n == 88125 else None
        events.append((s, lambda s=s, n=n, items=items, fm=fm, ins=ins: checkout(s, n, items, fraud_ms=fm, insert_ms=ins)))
    elif kind == "stock":
        sku = rnd.choice(SKUS)
        events.append((s, lambda s=s, sku=sku: stock(s, sku)))
    else:
        n = rnd.randint(88100, 88118)
        events.append((s, lambda s=s, n=n: order_lookup(s, n)))
    s += rnd.uniform(3.0, 6.5)

# the failed checkout and its retry: same correlation ID, new trace ID
events.append((15 * 60 + 1.900, lambda: checkout(15 * 60 + 1.900, 88123, ["KB-104", "MS-220"], cid=CID,
                                                 ip=CUSTOMER_IP, fraud_ms=4812.345, outcome="fraud_timeout",
                                                 trace=TR_FAIL)))
events.append((15 * 60 + 24.310, lambda: checkout(15 * 60 + 24.310, 88123, ["KB-104", "MS-220"], cid=CID,
                                                  ip=CUSTOMER_IP, fraud_ms=61.207, trace=TR_RETRY)))
# the decoy: a business failure, not a fault
events.append((15 * 60 + 41.200, lambda: checkout(15 * 60 + 41.200, 88127, ["HD-310", "MS-220"],
                                                  outcome="out_of_stock")))
events.sort(key=lambda e: e[0])
for _, fn in events:
    fn()

# ------------------------------------------------------------------ write files
names = {"gateway": "gateway.log", "orders": "orders-service.log", "inventory": "inventory.log",
         "payments": "payments.log", "fraud": "fraud-check.log", "shipping": "shipping-worker.log",
         "postgres": "postgres.log"}
for k, fname in names.items():
    lines = [l for _, l in sorted(logs[k], key=lambda x: x[0])]
    (out / fname).write_text("\n".join(lines) + "\n")
spans.sort(key=lambda sp: (sp["start"], sp["trace_id"]))
(out / "spans.json").write_text("[\n" + ",\n".join(json.dumps(sp) for sp in spans) + "\n]\n")
(out / "README.txt").write_text(
    "Day 1 Part 4 sample logs: one shop, seven components, 10:14 to 10:16:30 UTC on 6 Nov 2026.\n"
    "All data is invented. See the Part 4 lab guide (Labs 1.14 to 1.16).\n"
    "Helpers: ../bin/trace.py ID FILE...   and   ../bin/spantree.py [--list | --trace ID | --cid ID] spans.json\n")
print(f"wrote {len(names) + 2} files to {out}")
for k, fname in names.items():
    print(f"  {fname:<20} {len(logs[k]):>4} lines")
print(f"  spans.json           {len(spans):>4} spans, {len({sp['trace_id'] for sp in spans})} traces")
