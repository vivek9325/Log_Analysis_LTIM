"""Run two dangerous patterns with the regex module's timeout as a safety net."""
import time
import regex

text = "a" * 40 + "!"
for pattern in [r"^(a+)+$", r"^(a|aa)+$"]:
    t = time.perf_counter()
    try:
        m = regex.search(pattern, text, timeout=0.5)
        result = "match" if m else "no match"
    except TimeoutError:
        result = "TimeoutError"
    print(f"{pattern:12} {result:14} after {time.perf_counter() - t:.3f} s")
