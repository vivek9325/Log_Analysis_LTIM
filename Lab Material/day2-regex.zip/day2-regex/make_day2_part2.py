#!/usr/bin/env python3
"""Create the Day 2 Part 2 lab files: sample logs and regex test cases.

  samples/mixed.log        400 lines of mixed formats with traps for careless patterns
  samples/access.log       200 Nginx combined lines (for Grok)
  samples/app.log          120 Java-style application lines in a custom format (for Grok)
  samples/auth.log         60 sshd syslog lines (for Grok)
  cases/*.cases            test cases: expected value <TAB> input line, for rxtest.py

Everything is invented and deterministic: the same files every run.
Run:  python3 make_day2_part2.py [target-dir]      (default: ~/day2-regex)
"""
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "day2-regex")
for d in ("samples", "cases"):
    (root / d).mkdir(parents=True, exist_ok=True)
rnd = random.Random(20261107)
T0 = datetime(2026, 11, 7, 0, 0, 0, tzinfo=timezone.utc)
IPS = [f"198.51.100.{n}" for n in (7, 23, 45, 102, 199, 250)] + [f"203.0.113.{n}" for n in (9, 77, 128, 254)] + \
      ["192.0.2.1", "192.0.2.10"]
IP6 = ["2001:db8::1", "2001:db8:85a3::8a2e:370:7334", "2001:db8:0:1::42"]
PATHS = ["/", "/api/cart", "/api/checkout", "/products/sku-10037", "/search?q=boots", "/static/app.js",
         "/products/404-page-design", "/api/orders/ORD-771500"]
UAS = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64)", "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1 like Mac OS X)",
       "curl/8.5.0"]
STATUS = [200] * 14 + [201, 204, 301, 304, 400, 401, 403, 404, 404, 500, 502, 503, 504]
LEVELS = ["INFO"] * 6 + ["DEBUG", "WARN", "ERROR"]
CLASSES = ["c.e.orders.CheckoutService", "c.e.orders.PaymentsClient", "c.e.cart.CartController",
           "c.e.inventory.StockClient"]
MSGS = ["Payment declined: card expired", "Order placed", "Cart updated", "Stock reserved",
        "Timeout calling payments after 3000 ms", "Retrying request (attempt 2 of 3)"]


def hexid(n):
    return "".join(rnd.choice("0123456789abcdef") for _ in range(n))


def uuid4():
    h = hexid(32)
    return f"{h[:8]}-{h[8:12]}-4{h[13:16]}-{'89ab'[int(h[16], 16) % 4]}{h[17:20]}-{h[20:32]}"


def nginx(t, ip=None, status=None, size=None, path=None):
    ip = ip or rnd.choice(IPS)
    status = status or rnd.choice(STATUS)
    size = size if size is not None else rnd.randint(0, 9000)
    path = path or rnd.choice(PATHS)
    method = "POST" if path.startswith("/api/c") else "GET"
    return (f'{ip} - - [{t.strftime("%d/%b/%Y:%H:%M:%S +0000")}] "{method} {path} HTTP/1.1" {status} {size} '
            f'"https://shop.example.com/" "{rnd.choice(UAS)}" rt={rnd.randint(1, 900) / 1000:.3f} req_id={hexid(32)}')


def applog(t, level=None, user=True):
    ms = f"{t.microsecond // 1000:03d}"
    u = f" user=u-{rnd.randint(1000, 1999)}" if user else ""
    return (f"{t.strftime('%Y-%m-%d %H:%M:%S')},{ms} {level or rnd.choice(LEVELS):<5} "
            f"[http-nio-8080-exec-{rnd.randint(1, 10)}] {rnd.choice(CLASSES)} - req={hexid(32)}{u} "
            f"dur={rnd.randint(2, 4000)}ms {rnd.choice(MSGS)}")


def sshd(t, ok=False):
    ip = rnd.choice(IPS)
    host = "bastion-01"
    pid = rnd.randint(1000, 9999)
    day = f"{t.day:>2}"
    if ok:
        return f"{t.strftime('%b')} {day} {t.strftime('%H:%M:%S')} {host} sshd[{pid}]: Accepted publickey for deploy from {ip} port {rnd.randint(40000, 65000)} ssh2"
    inv = "invalid user " if rnd.random() < 0.6 else ""
    user = rnd.choice(["admin", "root", "oracle", "test", "ubuntu"])
    return f"{t.strftime('%b')} {day} {t.strftime('%H:%M:%S')} {host} sshd[{pid}]: Failed password for {inv}{user} from {ip} port {rnd.randint(40000, 65000)} ssh2"


# ------------------------------------------------------------------ samples
t = T0
mixed = []
for i in range(400):
    t += timedelta(milliseconds=rnd.randint(200, 3000))
    r = rnd.random()
    if r < 0.40:
        mixed.append(nginx(t))
    elif r < 0.62:
        mixed.append(applog(t))
    elif r < 0.72:
        mixed.append(sshd(t, ok=rnd.random() < 0.3))
    elif r < 0.80:
        mixed.append(f"{t.strftime('%Y-%m-%dT%H:%M:%S')}.{t.microsecond // 1000:03d}Z level=info msg=\"span\" "
                     f"traceparent=00-{hexid(32)}-{hexid(16)}-01 correlation_id={uuid4()}")
    elif r < 0.86:
        mixed.append(nginx(t, ip=rnd.choice(IP6)))
    else:                                           # traps: things that look like IPs, statuses, dates or IDs
        mixed.append(rnd.choice([
            f"{t.strftime('%Y-%m-%dT%H:%M:%S')}Z deploy finished: release 10.4.2.1 build 2026.11.07",
            f"{t.strftime('%Y-%m-%dT%H:%M:%S')}Z config error: upstream 999.12.3.4 is not a valid address",
            f"{t.strftime('%Y-%m-%dT%H:%M:%S')}Z cache stats hits=404 misses=500 evictions=200",
            f"{t.strftime('%Y-%m-%dT%H:%M:%S')}Z git commit {hexid(40)} merged",
            f"{t.strftime('%Y-%m-%dT%H:%M:%S')}Z order total 1504.99 EUR, 3 items",
        ]))
(root / "samples/mixed.log").write_text("\n".join(mixed) + "\n")

t = T0
acc = []
for i in range(200):
    t += timedelta(milliseconds=rnd.randint(200, 2500))
    acc.append(nginx(t, ip=rnd.choice(IPS + IP6[:1])))
acc[57] = acc[57].replace('"GET ', '"GET  ', 1) if '"GET ' in acc[57] else acc[57]   # a malformed request line
acc.insert(120, '198.51.100.23 - - [07/Nov/2026:00:03:12 +0000] "\\x16\\x03\\x01\\x00\\xa5" 400 157 "-" "-" rt=0.000 req_id=-')
(root / "samples/access.log").write_text("\n".join(acc) + "\n")

t = T0
app = []
for i in range(120):
    t += timedelta(milliseconds=rnd.randint(100, 4000))
    app.append(applog(t, user=(i % 17 != 5)))
(root / "samples/app.log").write_text("\n".join(app) + "\n")

t = T0
auth = []
for i in range(60):
    t += timedelta(seconds=rnd.randint(1, 40))
    auth.append(sshd(t, ok=rnd.random() < 0.25))
(root / "samples/auth.log").write_text("\n".join(auth) + "\n")

# ------------------------------------------------------------------ test cases: expected <TAB> line
CASES = {
    "ipv4.cases": [
        ("203.0.113.9", "Nov  7 00:12:01 bastion-01 sshd[4211]: Failed password for root from 203.0.113.9 port 51522 ssh2"),
        ("198.51.100.7", '198.51.100.7 - - [07/Nov/2026:00:00:01 +0000] "GET / HTTP/1.1" 200 512'),
        ("192.0.2.1", "client=[192.0.2.1]:443 connected"),
        ("0.0.0.0", "listening on 0.0.0.0:8080"),
        ("198.51.100.255", "broadcast 198.51.100.255"),
        ("192.0.2.10|198.51.100.23", "X-Forwarded-For: 192.0.2.10, 198.51.100.23"),
        ("", "upstream 999.12.3.4 is not a valid address"),
        ("", "host 10.0.0.256 rejected"),
        ("", "deploy finished: release 10.4.2.1.7 build 2026.11.07"),
        ("", "version 1.2.3 installed"),
        ("", "client 2001:db8::1 connected"),
        ("", "duration 12.345.678.901 ns"),
    ],
    "timestamps.cases": [
        ("2026-11-07T00:12:01.123Z", '2026-11-07T00:12:01.123Z level=info msg="span"'),
        ("2026-11-07T05:42:01+05:30", "ts=2026-11-07T05:42:01+05:30 level=warn"),
        ("2026-11-07 00:12:01,123", "2026-11-07 00:12:01,123 ERROR [main] c.e.App - boom"),
        ("2026-11-07T00:12:01Z", "deploy at 2026-11-07T00:12:01Z done"),
        ("", "2026-13-07T00:12:01Z month 13 does not exist"),
        ("", "2026-11-07T25:00:00Z hour 25 does not exist"),
        ("", "build 2026.11.07 published"),
        ("", "phone 2026-1107-0012 is not a date"),
    ],
    "status.cases": [
        ("200", '198.51.100.7 - - [07/Nov/2026:00:00:01 +0000] "GET / HTTP/1.1" 200 512 "-" "curl/8.5.0"'),
        ("404", '198.51.100.7 - - [07/Nov/2026:00:00:02 +0000] "GET /missing HTTP/1.1" 404 153 "-" "curl/8.5.0"'),
        ("200", '203.0.113.9 - - [07/Nov/2026:00:00:03 +0000] "GET /products/404-page-design HTTP/1.1" 200 9312 "-" "curl/8.5.0"'),
        ("301", '203.0.113.9 - - [07/Nov/2026:00:00:04 +0000] "GET /old HTTP/1.1" 301 500 "-" "curl/8.5.0"'),
        ("504", '192.0.2.1 - - [07/Nov/2026:00:00:05 +0000] "POST /api/checkout HTTP/1.1" 504 160 "-" "curl/8.5.0"'),
        ("400", '198.51.100.23 - - [07/Nov/2026:00:03:12 +0000] "\\x16\\x03\\x01" 400 157 "-" "-"'),
        ("", "cache stats hits=404 misses=500 evictions=200"),
        ("", "order total 1504.99 EUR, 3 items"),
    ],
    "correlation.cases": [
        ("3c9e7a1d-6b2f-4e58-a0d4-91f27c5b8e63", "correlation_id=3c9e7a1d-6b2f-4e58-a0d4-91f27c5b8e63 level=info"),
        ("3C9E7A1D-6B2F-4E58-A0D4-91F27C5B8E63", "X-Correlation-ID: 3C9E7A1D-6B2F-4E58-A0D4-91F27C5B8E63"),
        ("d5f5e4ff95f2822445b4b9de76daba00", "req_id=d5f5e4ff95f2822445b4b9de76daba00 rt=5.003"),
        ("4f1c9a7e2b6d4e0f9a3c5b7d1e2f4a68", "traceparent=00-4f1c9a7e2b6d4e0f9a3c5b7d1e2f4a68-743a6df1fa177f4c-01"),
        ("", "git commit 3f786850e387550fdab836ed7e6dc881de23001b merged"),
        ("", "req_id=d5f5e4ff95f2822445b4b9de76daba0 is one character short"),
        ("", "id 3c9e7a1d-6b2f-4e58-a0d4-91f27c5b8e6g has a g in it"),
        ("", "traceparent=00-00000000000000000000000000000000-743a6df1fa177f4c-01"),
    ],
}
for name, rows in CASES.items():
    (root / "cases" / name).write_text(
        "# expected value(s), separated by |, TAB, input line. An empty expectation means: no match.\n" +
        "\n".join(f"{e}\t{line}" for e, line in rows) + "\n")

print(f"wrote {root}")
for p in sorted((root / "samples").iterdir()):
    print(f"  samples/{p.name:<12} {sum(1 for _ in open(p)):>4} lines")
for p in sorted((root / "cases").iterdir()):
    print(f"  cases/{p.name:<18} {sum(1 for l in open(p) if not l.startswith('#')):>3} cases")
